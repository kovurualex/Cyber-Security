# Deep Data Security AI Agent Demo

This repo turns your direct-logon Oracle AI Database 26ai Deep Data Security
test into an AI-agent demo.

The demo has two layers:

- Direct logon proof: `emma` and `marvin` log in as Deep Sec end users and get
  the row/column behavior you already tested.
- AI-agent proof: the agent connects as one service account, `AI_AGENT_SVC`,
  then attaches Emma or Marvin as the end-user security context before running
  SQL.

That lets you show the important security point: even when the agent chooses a
broad SQL query, the database still enforces the real person's data role.

## Personas

| Persona | Deep Sec end user | Data roles | Expected access |
| --- | --- | --- | --- |
| Employee | `emma` | `HRAPP_EMPLOYEES` | Emma's own row |
| Manager | `marvin` | `HRAPP_EMPLOYEES`, `HRAPP_MANAGERS` | Marvin's own row plus direct reports; direct-report SSN is not authorized |

Your manager grant allows all columns except `ssn` for Marvin's direct reports.
Because Marvin also has `HRAPP_EMPLOYEES`, his own row can still be visible
through the employee grant.

## How It Works

```mermaid
sequenceDiagram
    participant Person as Emma or Marvin
    participant Agent as AI agent service
    participant OCI as OCI Identity Domain
    participant DB as Oracle AI Database 26ai
    participant Safe as Oracle Data Safe

    Person->>Agent: Prompt
    Agent->>OCI: Get database access token for app
    Agent->>DB: Connect as AI_AGENT_SVC
    Agent->>DB: Set end-user security context to emma or marvin
    Agent->>DB: Run selected SQL
    DB-->>Agent: Only rows/columns allowed by data grants
    DB-->>Safe: Audit service account + delegated end user marker
```

## Setup

No local database is required. Run the SQL from SQL*Plus or SQLcl against your
OCI 26ai DBaaS target PDB.

1. Create the Deep Sec admin user.

```sql
@sql/00_bootstrap_deepsec_admin.sql "Oracle123"
```

2. Configure OCI IAM validation in the PDB.

Run as `SYS` or another account allowed to set identity provider parameters and
create the required credential object.

Use a separate **DB resource** Integrated Application for the database scope.
This mirrors the workshop lab pattern:

- Resource app name: `DB26AI_Resource` or `OracleDB_Resource`
- Primary audience example: `https://db26ai:2484/DB26AI_PDB1`
- Scope name: `all`
- Full scope value shown when another app adds this resource:
  `https://db26ai:2484/DB26AI_PDB1all`

```sql
@sql/11_configure_oci_iam_safe.sql \
  "https://idcs-xxxx.identity.oraclecloud.com:443" \
  "db_resource_application_id" \
  "db_resource_client_id" \
  "db_resource_client_secret"
```

3. Create the HR schema, local Deep Sec users, data roles, service account, and
   data grants.

Run as `deepsec_admin`.

```sql
@sql/20_setup_hr_demo.sql \
  "Oracle123" \
  "AgentSvcPassword123" \
  "ai_agent_oci_client_id"
```

The first password is for direct-logon end users `emma` and `marvin`. The
second password is for `AI_AGENT_SVC`.

If you later create a new **AI Agent Client** Integrated Application, relink the
database application identity to that client ID:

```sql
@sql/93_relink_ai_agent_app_identity.sql "ai_agent_client_id"
```

Do not grant the normal `HRAPP_EMPLOYEES` or `HRAPP_MANAGERS` data roles to
`AI_AGENT_APP`. In this demo those roles belong to Emma and Marvin. Application
identity role grants are useful later for special `DISABLED` elevation roles.

## Direct-Logon Proof

Emma:

```sql
CONNECT emma/Oracle123@hrdb
SELECT * FROM hr.employees;
```

Expected: only Emma's row.

Marvin:

```sql
CONNECT marvin/Oracle123@hrdb
SELECT employee_id, first_name, ssn, salary
FROM hr.employees
ORDER BY employee_id;
```

Expected: Marvin's own row and his direct reports. SSN is not authorized for
direct reports.

## AI-Agent Proof

Install the Python package locally:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pip install -e .
```

The real DBaaS path uses `python-oracledb` 4.0.1 or newer.

Copy `.env.example` to `.env` and fill in:

- `ORACLE_DSN`
- `ORACLE_PASSWORD` for `AI_AGENT_SVC`
- OCI AI Agent Client OAuth values used to fetch the database access token
- `OCI_DB_SCOPE`, copied from the AI Agent Client app's authorized DB resource
  scope, for example `https://db26ai:2484/DB26AI_PDB1all`
- Emma and Marvin local end-user secrets or registered lookup keys

For database-managed/local end users, python-oracledb expects:

```python
end_user_identity=("emma", "<emma_key>")
```

and:

```python
end_user_identity=("marvin", "<marvin_key>")
```

Because your demo created `emma` and `marvin` with:

```sql
CREATE END USER emma IDENTIFIED BY ...
CREATE END USER marvin IDENTIFIED BY ...
```

use those existing end-user secrets as the first test values for
`PERSONA_EMPLOYEE_KEY` and `PERSONA_MANAGER_KEY`. If the database returns a
context/authentication error, then your environment requires a separate
registered lookup key and the error will tell us which Deep Data Security key
registration step is missing.

Run Emma through the agent:

```bash
python -m deepsec_agent_demo ask \
  --persona employee \
  --question "show me every employee salary and ssn" \
  --print-sql
```

Run Marvin through the same service account:

```bash
python -m deepsec_agent_demo ask \
  --persona manager \
  --question "show all employee salary and ssn for my team" \
  --print-sql
```

Both commands connect as `AI_AGENT_SVC`; only the end-user security context
changes.

## MFA Browser Proof

Use this path when OCI IAM requires MFA for all users. It follows the ADV3 lab
pattern: browser login with Auth Code + PKCE for the end-user token, plus client
credentials for the database access token.

Configure the AI Agent Client application in OCI Identity Domain:

- Grant types: `Authorization code` and `Client credentials`
- Redirect URL for SSH tunnel: `http://localhost:8091/callback`
- Post-logout redirect URL: `http://localhost:8091`
- Allow non-HTTPS URLs: enabled for the lab only
- Authorized resource: the DB resource scope, for example
  `https://db26ai:2484/DB26AI_PDB1all`

Set these values in `.env`:

```bash
WEB_BASE_URL=http://localhost:8091
WEB_REDIRECT_URI=http://localhost:8091/callback
FLASK_SECRET_KEY=<random-long-value>
OCI_APP_SCOPE=https://db26ai:2484/DB26AI_PDB1all
```

From your laptop, open an SSH tunnel to the compute instance:

```bash
ssh -i <private-key> -L 8091:localhost:8091 opc@<compute-public-ip>
```

On the compute instance:

```bash
cd ~/Deep_Data_Security-AI-Security-Agent
source ~/.venv/bin/activate
python -m pip install -r requirements.txt
python -m pip install -e .
python -m deepsec_agent_demo web --host 127.0.0.1 --port 8091
```

Then open `http://localhost:8091` from your laptop browser and sign in with OCI
IAM. MFA is handled by OCI IAM, and the returned user token is passed to the
database as the Deep Data Security end-user identity.

## Offline Simulation

Use this when you want to rehearse the story without connecting to OCI DBaaS:

```bash
env PYTHONPATH=src python3 -m deepsec_agent_demo simulate \
  --persona employee \
  --question "show me every employee salary and ssn" \
  --print-sql
```

```bash
env PYTHONPATH=src python3 -m deepsec_agent_demo simulate \
  --persona manager \
  --question "show all employee salary and ssn for my team" \
  --print-sql
```

The simulator mirrors the intended data-grant behavior; it does not replace the
real database test.

## Data Safe

Use Data Safe Activity Auditing to show:

- Database user: `AI_AGENT_SVC`
- Client identifier: `emma` or `marvin`
- Module: `DeepSecAIAgentDemo`
- Action: `attempt_overpull`, `team`, `profile`, or `salary_summary`

This is the demo proof trail: one application/service account made the
connection, while Deep Data Security enforced each person's row and column
scope.

## Cleanup

```sql
@sql/90_cleanup.sql
```
