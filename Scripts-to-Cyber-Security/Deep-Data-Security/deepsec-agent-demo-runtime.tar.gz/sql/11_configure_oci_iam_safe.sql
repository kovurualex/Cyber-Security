SET ECHO OFF
SET VERIFY OFF
SET FEEDBACK 1
SET LINESIZE 200
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

-- Safer version of 10_configure_oci_iam.sql.
-- It avoids echoing the client secret into SQL*Plus output/spool logs.
--
-- Usage:
--   @sql/11_configure_oci_iam_safe.sql "<domain_url>" "<application_id_or_client_id>" "<client_id>" "<client_secret>"

DEFINE domain_url = '&1'
DEFINE db_application_id = '&2'
DEFINE db_client_id = '&3'
DEFINE db_client_secret = '&4'

SPOOL 11_configure_oci_iam_safe.log

PROMPT === Configure OCI IAM identity provider ===

ALTER SYSTEM SET IDENTITY_PROVIDER_TYPE = OCI_IAM SCOPE = BOTH;

ALTER SYSTEM SET IDENTITY_PROVIDER_OAUTH_CONFIG = '{
  "app_id": "&db_application_id",
  "domain_url": "&domain_url"
}' SCOPE = BOTH;

PROMPT === Create or replace OCI_IAM_DOMAIN_DB_CRED$ credential ===

DECLARE
  credential_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(credential_exists, -27477);
BEGIN
  DBMS_CREDENTIAL.CREATE_CREDENTIAL(
    credential_name => 'OCI_IAM_DOMAIN_DB_CRED$',
    username        => '&db_client_id',
    password        => '&db_client_secret'
  );
EXCEPTION
  WHEN credential_exists THEN
    DBMS_CREDENTIAL.DROP_CREDENTIAL('OCI_IAM_DOMAIN_DB_CRED$');
    DBMS_CREDENTIAL.CREATE_CREDENTIAL(
      credential_name => 'OCI_IAM_DOMAIN_DB_CRED$',
      username        => '&db_client_id',
      password        => '&db_client_secret'
    );
END;
/

PROMPT === Verify identity provider parameters ===
SHOW PARAMETER identity

SPOOL OFF

UNDEFINE domain_url
UNDEFINE db_application_id
UNDEFINE db_client_id
UNDEFINE db_client_secret
