SET ECHO ON
SET FEEDBACK 1
SET LINESIZE 200
SET PAGESIZE 100

PROMPT Run these checks inside an application-mediated end-user session.

SELECT JSON_SERIALIZE(ORA_END_USER_CONTEXT RETURNING CLOB PRETTY)
  AS end_user_context
FROM dual;

SELECT employee_id,
       first_name,
       last_name,
       job_code,
       department_id,
       DECODE(
         ORA_IS_COLUMN_AUTHORIZED(ssn),
         FALSE, 'NOT_AUTHORIZED',
         TRUE, ssn
       ) AS ssn,
       phone_number,
       salary,
       user_name,
       manager_id
FROM hr.employees
ORDER BY employee_id;

SELECT department_id,
       COUNT(*) AS employee_count,
       MIN(salary) AS min_salary,
       MAX(salary) AS max_salary,
       ROUND(AVG(salary), 2) AS avg_salary
FROM hr.employees
GROUP BY department_id
ORDER BY department_id;
