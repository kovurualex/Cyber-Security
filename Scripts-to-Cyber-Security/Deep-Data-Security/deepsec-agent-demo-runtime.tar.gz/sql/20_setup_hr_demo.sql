SET ECHO ON
SET FEEDBACK 1
SET LINESIZE 200
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

DEFINE end_user_password = '&1'
DEFINE agent_password = '&2'
DEFINE app_client_id = '&3'

SPOOL 20_setup_hr_demo.log

CREATE USER hr NO AUTHENTICATION
  DEFAULT TABLESPACE users;

ALTER USER hr QUOTA UNLIMITED ON users;

CREATE TABLE hr.employees (
  employee_id   NUMBER PRIMARY KEY,
  first_name    VARCHAR2(50),
  last_name     VARCHAR2(50),
  job_code      VARCHAR2(10),
  department_id NUMBER,
  ssn           VARCHAR2(20),
  photo         BLOB,
  phone_number  VARCHAR2(30),
  salary        NUMBER(10,2),
  user_name     VARCHAR2(128),
  manager_id    NUMBER
);

INSERT INTO hr.employees VALUES (
  1, 'Grace', 'Young', 'CEO', NULL, '111-11-1111', NULL,
  '555-100-0001', 235000, 'grace', NULL
);

INSERT INTO hr.employees VALUES (
  2, 'Marvin', 'Morgan', 'SWE_MGR', 1, '222-22-2222', NULL,
  '555-100-0002', 175000, 'marvin', 1
);

INSERT INTO hr.employees VALUES (
  3, 'Emma', 'Baker', 'SWE2', 1, '333-33-3333', NULL,
  '555-100-0003', 120000, 'emma', 2
);

INSERT INTO hr.employees VALUES (
  4, 'Charlie', 'Davis', 'SWE1', 1, '444-44-4444', NULL,
  '555-100-0004', 95000, 'charlie', 2
);

INSERT INTO hr.employees VALUES (
  5, 'Dana', 'Lee', 'SWE3', 1, '555-55-5555', NULL,
  '555-100-0005', 130000, 'dana', 2
);

INSERT INTO hr.employees VALUES (
  6, 'Bob', 'Smith', 'SALES_REP', 2, '666-66-6666', NULL,
  '555-100-0006', 145000, 'bob', 1
);

INSERT INTO hr.employees VALUES (
  7, 'Fiona', 'Chen', 'HR_REP', 3, '777-77-7777', NULL,
  '555-100-0007', 92000, 'fiona', 1
);

CREATE TABLE hr.managers (
  manager_id      NUMBER,
  employee_id     NUMBER,
  mgr_user_name   VARCHAR2(128),
  mgr_first_name  VARCHAR2(50),
  mgr_last_name   VARCHAR2(50)
);

INSERT INTO hr.managers (
  manager_id,
  employee_id,
  mgr_user_name,
  mgr_first_name,
  mgr_last_name
)
SELECT e.manager_id,
       e.employee_id,
       m.user_name AS mgr_user_name,
       m.first_name AS mgr_first_name,
       m.last_name AS mgr_last_name
FROM hr.employees e
JOIN hr.employees m
  ON e.manager_id = m.employee_id
WHERE e.manager_id IS NOT NULL;

COMMIT;

CREATE END USER emma IDENTIFIED BY "&end_user_password";
CREATE END USER marvin IDENTIFIED BY "&end_user_password";

CREATE ROLE direct_logon_role;
GRANT CREATE SESSION TO direct_logon_role;

CREATE DATA ROLE hrapp_employees;
CREATE DATA ROLE hrapp_managers;

GRANT DATA ROLE hrapp_employees TO emma;
GRANT DATA ROLE hrapp_employees TO marvin;
GRANT DATA ROLE hrapp_managers TO marvin;

GRANT direct_logon_role TO hrapp_employees;

CREATE USER ai_agent_svc IDENTIFIED BY "&agent_password";
GRANT CREATE SESSION TO ai_agent_svc;
GRANT CREATE END USER SECURITY CONTEXT TO ai_agent_svc;

CREATE OR REPLACE APPLICATION IDENTITY ai_agent_app
  MAPPED TO 'IAM_OAUTH_CLIENT_ID=&app_client_id';

CREATE OR REPLACE DATA GRANT hr.hrapp_employee_access
  AS SELECT, UPDATE (phone_number, first_name)
  ON hr.employees
  WHERE UPPER(user_name) = UPPER(ORA_END_USER_CONTEXT.username)
  TO hrapp_employees;

CREATE OR REPLACE DATA GRANT hr.hrapp_manager_access
  AS SELECT (ALL COLUMNS EXCEPT ssn),
     UPDATE (salary, department_id, first_name)
  ON hr.employees
  WHERE manager_id IN (
    SELECT m.manager_id
    FROM hr.managers m
    WHERE UPPER(m.mgr_user_name) = UPPER(ORA_END_USER_CONTEXT.username)
  )
  TO hrapp_managers;

SET USE DATA GRANTS ONLY ON hr.employees ENABLED;

SELECT data_role, role_type, grantee, grantee_type
FROM dba_data_role_grants
ORDER BY data_role, grantee;

SELECT column_name, grant_name, privilege, grantee
FROM dba_data_grants
WHERE object_owner = 'HR'
  AND object_name = 'EMPLOYEES'
ORDER BY grant_name, privilege, column_name;

SELECT DISTINCT grant_name, predicate
FROM dba_data_grants
WHERE object_owner = 'HR'
  AND object_name = 'EMPLOYEES'
ORDER BY grant_name;

SPOOL OFF
