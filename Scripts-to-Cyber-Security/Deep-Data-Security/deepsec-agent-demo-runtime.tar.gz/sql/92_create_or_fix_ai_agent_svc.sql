SET ECHO ON
SET FEEDBACK 1
SET LINESIZE 200
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

-- Creates or fixes the AI agent database service account after the accidental
-- SYS run. Your log showed AgentSvcPassword123 failed password complexity.
--
-- Use a password that satisfies your profile, for example with at least two
-- special characters:
--   @sql/92_create_or_fix_ai_agent_svc.sql "AgentSvcPassword123##"

DEFINE agent_password = '&1'

SPOOL 92_create_or_fix_ai_agent_svc.log

SHOW CON_NAME

DECLARE
  l_count NUMBER;
BEGIN
  SELECT COUNT(*)
  INTO l_count
  FROM dba_users
  WHERE username = 'AI_AGENT_SVC';

  IF l_count = 0 THEN
    EXECUTE IMMEDIATE 'CREATE USER ai_agent_svc IDENTIFIED BY "&agent_password"';
  ELSE
    EXECUTE IMMEDIATE 'ALTER USER ai_agent_svc IDENTIFIED BY "&agent_password" ACCOUNT UNLOCK';
  END IF;
END;
/

GRANT CREATE SESSION TO ai_agent_svc;
GRANT CREATE END USER SECURITY CONTEXT TO ai_agent_svc;

SELECT username, account_status
FROM dba_users
WHERE username = 'AI_AGENT_SVC';

SPOOL OFF
