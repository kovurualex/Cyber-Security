SET ECHO ON
SET FEEDBACK 1
SET LINESIZE 200
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

-- Use this after creating the two OCI Identity Domain applications:
--   1. DB resource application, which defines the database scope
--   2. AI agent client application, which requests that scope
--
-- Pass the AI agent client application's Client ID here. Do not pass the
-- DB resource application's Application ID.
--
-- Usage:
--   @sql/93_relink_ai_agent_app_identity.sql "<ai_agent_client_id>"

DEFINE app_client_id = '&1'

SPOOL 93_relink_ai_agent_app_identity.log

SHOW CON_NAME

CREATE OR REPLACE APPLICATION IDENTITY ai_agent_app
  MAPPED TO 'IAM_OAUTH_CLIENT_ID=&app_client_id';

PROMPT === Application identity mapping ===

SELECT 'AI_AGENT_APP mapped to IAM_OAUTH_CLIENT_ID=&app_client_id' AS mapping
FROM dual;

PROMPT === Existing data-role grants for Emma and Marvin ===

SELECT data_role, role_type, grantee, grantee_type
FROM dba_data_role_grants
WHERE grantee IN ('EMMA', 'MARVIN')
ORDER BY data_role, grantee;

PROMPT === Note ===
PROMPT Normal HRAPP data roles are intentionally granted to end users, not to AI_AGENT_APP.
PROMPT Grant only DISABLED elevation roles to an application identity in later demos.

SPOOL OFF

UNDEFINE app_client_id
