SET ECHO ON
SET FEEDBACK 1
SET LINESIZE 200
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

-- Use this after accidentally rerunning 20_setup_hr_demo.sql as SYS.
--
-- What it fixes:
--   1. Rebuilds HR.MANAGERS from HR.EMPLOYEES to remove duplicate lookup rows.
--   2. Optionally replaces AI_AGENT_APP with the real OCI IAM client ID.
--
-- Run in the target PDB, preferably as SYS or another DBA user:
--   ALTER SESSION SET CONTAINER=DB26AI_PDB1;
--   @sql/91_repair_after_accidental_sys_run.sql "real-ai-agent-client-id"
--
-- If you do not have the real client ID yet, pass "placeholder-client-id".

DEFINE app_client_id = '&1'

SPOOL 91_repair_after_accidental_sys_run.log

PROMPT === Confirm current container ===
SHOW CON_NAME

PROMPT === Before repair: row counts ===
SELECT COUNT(*) AS employee_rows FROM hr.employees;
SELECT COUNT(*) AS manager_rows FROM hr.managers;

PROMPT === Before repair: duplicate manager lookup rows ===
SELECT manager_id,
       employee_id,
       mgr_user_name,
       COUNT(*) AS duplicate_count
FROM hr.managers
GROUP BY manager_id, employee_id, mgr_user_name
HAVING COUNT(*) > 1
ORDER BY employee_id;

PROMPT === Rebuild HR.MANAGERS from HR.EMPLOYEES ===
DELETE FROM hr.managers;

INSERT INTO hr.managers (
  manager_id,
  employee_id,
  mgr_user_name,
  mgr_first_name,
  mgr_last_name
)
SELECT e.manager_id,
       e.employee_id,
       m.user_name AS mgr_user_name,
       m.first_name AS mgr_first_name,
       m.last_name AS mgr_last_name
FROM hr.employees e
JOIN hr.employees m
  ON e.manager_id = m.employee_id
WHERE e.manager_id IS NOT NULL;

COMMIT;

PROMPT === After repair: row counts ===
SELECT COUNT(*) AS employee_rows FROM hr.employees;
SELECT COUNT(*) AS manager_rows FROM hr.managers;

PROMPT === After repair: duplicate manager lookup rows should be zero rows ===
SELECT manager_id,
       employee_id,
       mgr_user_name,
       COUNT(*) AS duplicate_count
FROM hr.managers
GROUP BY manager_id, employee_id, mgr_user_name
HAVING COUNT(*) > 1
ORDER BY employee_id;

PROMPT === Replace application identity mapping if a real client ID is supplied ===
CREATE OR REPLACE APPLICATION IDENTITY ai_agent_app
  MAPPED TO 'IAM_OAUTH_CLIENT_ID=&app_client_id';

PROMPT === Verify data grants are still present ===
SELECT data_role, role_type, grantee, grantee_type
FROM dba_data_role_grants
WHERE data_role IN ('HRAPP_EMPLOYEES', 'HRAPP_MANAGERS', 'DIRECT_LOGON_ROLE')
   OR grantee IN ('EMMA', 'MARVIN', 'HRAPP_EMPLOYEES')
ORDER BY data_role, grantee;

SELECT DISTINCT grant_name, predicate
FROM dba_data_grants
WHERE object_owner = 'HR'
  AND object_name = 'EMPLOYEES'
ORDER BY grant_name;

PROMPT === Verify direct-logon expected result counts ===
PROMPT Emma should see 1 HR.EMPLOYEES row.
PROMPT Marvin should see 4 HR.EMPLOYEES rows: Marvin, Emma, Charlie, Dana.

SPOOL OFF
