SET ECHO ON
SET FEEDBACK 1
SET LINESIZE 200
SET TRIMSPOOL ON
SET TAB OFF
SET PAGESIZE 100

DEFINE domain_url = '&1'
DEFINE db_application_id = '&2'
DEFINE db_client_id = '&3'
DEFINE db_client_secret = '&4'

SPOOL 10_configure_oci_iam.log

ALTER SYSTEM SET IDENTITY_PROVIDER_TYPE = OCI_IAM SCOPE = BOTH;

ALTER SYSTEM SET IDENTITY_PROVIDER_OAUTH_CONFIG = '{
  "app_id": "&db_application_id",
  "domain_url": "&domain_url"
}' SCOPE = BOTH;

BEGIN
  DBMS_CREDENTIAL.CREATE_CREDENTIAL(
    credential_name => 'OCI_IAM_DOMAIN_DB_CRED$',
    username        => '&db_client_id',
    password        => '&db_client_secret'
  );
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE = -27477 THEN
      DBMS_CREDENTIAL.DROP_CREDENTIAL('OCI_IAM_DOMAIN_DB_CRED$');
      DBMS_CREDENTIAL.CREATE_CREDENTIAL(
        credential_name => 'OCI_IAM_DOMAIN_DB_CRED$',
        username        => '&db_client_id',
        password        => '&db_client_secret'
      );
    ELSE
      RAISE;
    END IF;
END;
/

SHOW PARAMETER identity

SPOOL OFF
