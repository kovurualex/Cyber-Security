# Deep Data Security AI Agent Demo Setup Guide

This guide assumes you already have an Oracle AI Database 26ai Base DBaaS
database and Oracle Data Safe configured.

The demo is easiest to run in three phases:

1. Prove Deep Data Security with direct end-user logon.
2. Prove the same policy through one AI-agent service account.
3. Add OCI Generative AI, RAG, and MCP around the same secured database call.

Replace `hrdb` with your real PDB service name.

## 0. Prerequisites

You need:

- SQLcl or SQL*Plus access to the target PDB.
- A DBA/SYS connection to the PDB.
- This repo on your laptop, Cloud Shell, or a jump host that can reach DBaaS.
- Python 3.10 or newer for the demo agent.
- `python-oracledb` 4.0.1 or newer.
- OCI IAM/Identity Domain values for the database access token flow.
- Optional but recommended: OCI Generative AI project for the LLM/RAG/MCP layer.

Confirm you are connected to the PDB, not CDB root:

```sql
CONNECT sys/<password>@hrdb AS SYSDBA
SHOW CON_NAME
SELECT banner_full FROM v$version;
```

## 1. Create the Deep Sec Admin User

Run as `SYS` or another DBA user in the target PDB:

```sql
@sql/00_bootstrap_deepsec_admin.sql "Oracle123"
```

This creates `deepsec_admin` and grants the privileges needed to create end
users, data roles, data grants, application identities, and mandatory data grant
enforcement.

## 2. Configure OCI IAM Token Validation

This phase lets the database validate the application token used by the agent.

Collect these values from your OCI IAM / Identity Domain application setup:

- Identity domain URL, for example `https://idcs-xxxx.identity.oraclecloud.com:443`
- Database application ID
- Database OAuth client ID
- Database OAuth client secret

Run as `SYS` in the PDB:

```sql
@sql/10_configure_oci_iam.sql \
  "https://idcs-xxxx.identity.oraclecloud.com:443" \
  "database_application_id" \
  "database_oauth_client_id" \
  "database_oauth_client_secret"
```

Expected check:

```sql
SHOW PARAMETER identity
```

You should see `IDENTITY_PROVIDER_TYPE` set to `OCI_IAM`.

## 3. Create the HR Demo, End Users, Data Roles, and Grants

Run as `deepsec_admin`:

```sql
CONNECT deepsec_admin/Oracle123@hrdb

@sql/20_setup_hr_demo.sql \
  "Oracle123" \
  "AgentSvcPassword123" \
  "ai_agent_oci_client_id"
```

Parameter meaning:

- `Oracle123`: password for local Deep Sec end users `emma` and `marvin`.
- `AgentSvcPassword123`: password for the database service account
  `AI_AGENT_SVC`.
- `ai_agent_oci_client_id`: OCI IAM OAuth client ID used by the AI-agent
  application. It must match the client ID that will fetch the database access
  token.

The script creates:

- `hr.employees`
- `hr.managers`
- Deep Sec end users `emma` and `marvin`
- Data roles `HRAPP_EMPLOYEES` and `HRAPP_MANAGERS`
- Data grants `HRAPP_EMPLOYEE_ACCESS` and `HRAPP_MANAGER_ACCESS`
- Service account `AI_AGENT_SVC`
- Mandatory enforcement with:

```sql
SET USE DATA GRANTS ONLY ON hr.employees ENABLED;
```

## 4. Prove Direct End-User Behavior

Emma:

```sql
CONNECT emma/Oracle123@hrdb

SELECT employee_id, first_name, last_name, job_code, ssn, salary, user_name, manager_id
FROM hr.employees
ORDER BY employee_id;
```

Expected: only Emma's row.

Marvin:

```sql
CONNECT marvin/Oracle123@hrdb

SELECT employee_id, first_name, last_name, job_code, ssn, salary, user_name, manager_id
FROM hr.employees
ORDER BY employee_id;
```

Expected: Marvin's own row plus Emma, Charlie, and Dana. Direct-report `ssn`
is not authorized or masked.

Metadata checks:

```sql
SELECT data_role, role_type, grantee, grantee_type
FROM dba_data_role_grants
ORDER BY data_role, grantee;

SELECT column_name, grant_name, privilege, grantee
FROM dba_data_grants
WHERE object_owner = 'HR'
  AND object_name = 'EMPLOYEES'
ORDER BY grant_name, privilege, column_name;

SELECT DISTINCT grant_name, predicate
FROM dba_data_grants
WHERE object_owner = 'HR'
  AND object_name = 'EMPLOYEES'
ORDER BY grant_name;
```

## 5. Prove the Same Policy Through the AI-Agent Service Account

The service account always connects as:

```text
AI_AGENT_SVC
```

The application then attaches an end-user security context:

```python
("emma", "<emma_security_context_lookup_key>")
```

or:

```python
("marvin", "<marvin_security_context_lookup_key>")
```

For this demo, first use the same secret you used when creating the
database-managed end users:

```sql
CREATE END USER emma IDENTIFIED BY ...
CREATE END USER marvin IDENTIFIED BY ...
```

That means the first test values are the existing Emma and Marvin end-user
passwords. If your environment is configured to require separate registered
lookup keys, the real DB run will fail with a context/authentication error; keep
that error and use the separate registered key value instead.

Create `.env`:

```bash
cp .env.example .env
```

Edit `.env`:

```bash
ORACLE_DSN=<db-host>:1521/<pdb-service>
ORACLE_USER=AI_AGENT_SVC
ORACLE_PASSWORD=AgentSvcPassword123

OCI_DOMAIN_URL=https://idcs-xxxx.identity.oraclecloud.com:443
OCI_APP_CLIENT_ID=<ai-agent-client-app-client-id>
OCI_APP_CLIENT_SECRET=<ai-agent-client-secret>
OCI_DB_SCOPE=https://db26ai:2484/DB26AI_PDB1all
# OCI_APP_SCOPE is only needed for IAM username/password end-user tokens.
# OCI_APP_SCOPE=<optional-end-user-app-scope>

PERSONA_EMPLOYEE_END_USER=emma
PERSONA_EMPLOYEE_KEY=<emma_end_user_secret_or_registered_key>
PERSONA_MANAGER_END_USER=marvin
PERSONA_MANAGER_KEY=<marvin_end_user_secret_or_registered_key>
```

For TCPS/wallet connections, also set:

```bash
ORACLE_WALLET_LOCATION=/path/to/wallet
ORACLE_WALLET_PASSWORD=<wallet-password>
```

The `OCI_DB_SCOPE` value must come from the two-application OCI Identity Domain
setup:

1. DB Resource application defines the database API.
2. AI Agent Client application is authorized to request that DB Resource scope.
3. If the DB Resource primary audience is `https://db26ai:2484/DB26AI_PDB1`
   and the scope name is `all`, the full scope is
   `https://db26ai:2484/DB26AI_PDB1all`.

This is why `db-access`, `deepsec-ai-agent-demo/db-access`, and
`urn:opc:idm:__myscopes__` are not the right values for the database access
token. The first two are not registered scopes in the Identity Domain, and the
last one returns Identity Domain administration scopes, not a database resource
token.

Install and run:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m pip install -e .
```

Offline rehearsal, no database needed:

```bash
python -m deepsec_agent_demo simulate \
  --persona employee \
  --question "show all employee salary and SSN" \
  --print-sql

python -m deepsec_agent_demo simulate \
  --persona manager \
  --question "show all employee salary and SSN for my team" \
  --print-sql
```

Real DBaaS run:

```bash
python -m deepsec_agent_demo ask \
  --persona employee \
  --question "show all employee salary and SSN" \
  --print-sql

python -m deepsec_agent_demo ask \
  --persona manager \
  --question "show all employee salary and SSN for my team" \
  --print-sql
```

Expected result:

- The SQL is intentionally broad.
- The connection user is still `AI_AGENT_SVC`.
- Emma receives only Emma's allowed data.
- Marvin receives his allowed rows, with direct-report `ssn` protected by the
  data grant.

## 6. Add OCI Generative AI, RAG, and MCP

Keep this first demo simple. Do not start with fully autonomous SQL generation.
Use the model to choose a tool, but keep the tool implementation small and
controlled.

Recommended demo shape:

```text
End user
  -> OCI Generative AI Responses API
  -> RAG over demo/policy documents
  -> MCP tool: query_hr_demo(persona, question)
  -> AI_AGENT_SVC database session
  -> Deep Data Security data grants
  -> allowed result only
```

### 6.1 LLM

In OCI Generative AI:

1. Create or select a Generative AI project.
2. Use the OCI Responses API.
3. Pick one supported chat/reasoning model in your region.
4. Use either OCI Generative AI API key auth for a sandbox demo or OCI IAM auth
   for a production-like demo.

### 6.2 RAG

For a simple RAG story, create an OCI Generative AI vector store / File Search
source with:

- `README.md`
- `DEMO_SETUP_GUIDE.md`
- `sql/20_setup_hr_demo.sql`
- The 2-slide PPTX in `outputs/`

Purpose: the model can explain the demo, the policy, and why Emma and Marvin
see different results. The RAG content is for explanation, not for bypassing
database policy.

### 6.3 MCP

Expose one remote MCP tool:

```text
query_hr_demo(persona, question)
```

The tool should:

1. Accept `persona = employee` or `persona = manager`.
2. Map the persona to the correct end-user context:
   - `employee` -> `emma`
   - `manager` -> `marvin`
3. Call the same service-account code used by:

```bash
python -m deepsec_agent_demo ask ...
```

4. Return only the database result.

Important guardrail: do not expose a generic `run_sql(sql_text)` tool in the
first demo. The stronger story is that even if the internal SQL is broad, Deep
Data Security still enforces rows and columns.

OCI Generative AI MCP Calling uses a tool entry with `"type": "mcp"` and a
remote MCP server URL. Limit exposed tools with `allowed_tools`.

## 7. Show the Data Safe Proof

Run the two real agent calls first, then open Data Safe Activity Auditing.

Filter or search for:

- Database user: `AI_AGENT_SVC`
- Client identifier: `emma` or `marvin`
- Module: `DeepSecAIAgentDemo`
- Action: `attempt_overpull`, `team`, or `profile`
- SQL text touching `HR.EMPLOYEES`

Talking point:

> Data Safe shows the one service account executing the query, while Deep Data
> Security shows that the effective data boundary followed Emma or Marvin.

## 8. Present the Demo

Use the generated deck:

```text
outputs/deep-data-security-ai-agent-demo.pptx
```

Recommended live flow:

1. Show slide 1: LLM + RAG + MCP is simple integration around the existing app.
2. Show direct logon as Emma.
3. Show direct logon as Marvin.
4. Show the same prompt through the agent service account.
5. Open Data Safe and show `AI_AGENT_SVC` with client identifier/action.
6. Show slide 2: same agent query, different allowed result.

## 9. Troubleshooting

## 9A. MFA-Friendly Web Flow

If every OCI IAM user requires MFA, do not use Resource Owner Password flow.
Use Auth Code + PKCE instead.

### OCI Identity Domain

In the **AI Agent Client** integrated application:

```text
Grant types:
  Authorization code
  Client credentials

Redirect URL:
  http://localhost:8091/callback

Post-logout redirect URL:
  http://localhost:8091

Allow non-HTTPS URLs:
  Enabled for lab only

Authorized resource:
  DB26AI_Resource / all
```

The full resource scope should still be:

```text
https://db26ai:2484/DB26AI_PDB1all
```

### Compute `.env`

```bash
OCI_DB_SCOPE=https://db26ai:2484/DB26AI_PDB1all
OCI_APP_SCOPE=https://db26ai:2484/DB26AI_PDB1all
WEB_BASE_URL=http://localhost:8091
WEB_REDIRECT_URI=http://localhost:8091/callback
FLASK_SECRET_KEY=<random-long-value>
```

Keep Python Thin mode:

```bash
ORACLE_THICK_MODE=false
```

### Run With SSH Tunnel

From your laptop:

```bash
ssh -i <private-key> -L 8091:localhost:8091 opc@<compute-public-ip>
```

On the compute instance:

```bash
cd ~/Deep_Data_Security-AI-Security-Agent
source ~/.venv/bin/activate
python -m pip install -r requirements.txt
python -m pip install -e .
python -m deepsec_agent_demo web --host 127.0.0.1 --port 8091
```

Open this from your laptop:

```text
http://localhost:8091
```

Login with OCI IAM. The web page shows the user token claims, the planned SQL,
and the rows returned by Deep Data Security.

No rows returned:

- Check that the end-user name is `emma` or `marvin`.
- Check case-insensitive predicate logic in the data grant.
- Check that the local end-user lookup key matches the end user.

Too many rows returned:

- Confirm this is enabled:

```sql
SET USE DATA GRANTS ONLY ON hr.employees ENABLED;
```

- Confirm the test is not connecting as `SYS`, `HR`, or another privileged DBA.

App-mediated context fails:

- Confirm `AI_AGENT_SVC` has `CREATE END USER SECURITY CONTEXT`.
- Confirm OCI IAM token validation is configured.
- Confirm `OCI_APP_CLIENT_ID` is the AI Agent Client application's Client ID.
- Confirm the database application identity maps to that same AI Agent Client
  ID:

```sql
@sql/93_relink_ai_agent_app_identity.sql "<ai-agent-client-app-client-id>"
```

- Confirm `OCI_DB_SCOPE` is the full DB Resource scope shown in the AI Agent
  Client app's **Token issuance policy** resource table.

MCP call cannot reach the server:

- The MCP server URL must be reachable by OCI Generative AI.
- Use HTTPS.
- Start with one exposed tool and use `allowed_tools`.

Data Safe does not show the event:

- Confirm Activity Auditing is enabled for the target database.
- Wait for audit collection latency.
- Filter by `AI_AGENT_SVC` first, then by SQL text or module/action.

## 10. Cleanup

Run as `deepsec_admin`:

```sql
@sql/90_cleanup.sql
```

If cleanup fails because an object was already removed, manually drop the
remaining data grants, data roles, local end users, `AI_AGENT_SVC`, and `HR`.
