from __future__ import annotations

from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION_START
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


OUT = Path("outputs/deep-data-security-ai-agent-demo-runbook.docx")

BLUE = RGBColor(46, 116, 181)
DARK_BLUE = RGBColor(31, 77, 120)
INK = RGBColor(31, 41, 36)
MUTED = RGBColor(91, 103, 96)
LIGHT_BLUE = "E8EEF5"
LIGHT_GRAY = "F4F6F9"
PALE_GREEN = "EAF4EF"
PALE_RED = "FCEEEE"
WHITE = RGBColor(255, 255, 255)


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_width(cell, width_inches: float) -> None:
    cell.width = Inches(width_inches)
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_w = tc_pr.find(qn("w:tcW"))
    if tc_w is None:
        tc_w = OxmlElement("w:tcW")
        tc_pr.append(tc_w)
    tc_w.set(qn("w:type"), "dxa")
    tc_w.set(qn("w:w"), str(int(width_inches * 1440)))


def set_table_fixed(table, widths: list[float]) -> None:
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:type"), "dxa")
    tbl_w.set(qn("w:w"), str(sum(int(w * 1440) for w in widths)))

    for row in table.rows:
        for idx, cell in enumerate(row.cells):
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_width(cell, widths[idx])


def set_cell_margins(table, top=80, start=120, bottom=80, end=120) -> None:
    tbl_pr = table._tbl.tblPr
    tbl_cell_mar = tbl_pr.find(qn("w:tblCellMar"))
    if tbl_cell_mar is None:
        tbl_cell_mar = OxmlElement("w:tblCellMar")
        tbl_pr.append(tbl_cell_mar)
    for m, v in [("top", top), ("start", start), ("bottom", bottom), ("end", end)]:
        node = tbl_cell_mar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tbl_cell_mar.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")


def set_run_font(run, *, name="Calibri", size=None, color=None, bold=None, italic=None):
    run.font.name = name
    run._element.rPr.rFonts.set(qn("w:ascii"), name)
    run._element.rPr.rFonts.set(qn("w:hAnsi"), name)
    if size is not None:
        run.font.size = Pt(size)
    if color is not None:
        run.font.color.rgb = color
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic


def set_paragraph_spacing(paragraph, *, before=0, after=6, line=1.25):
    pf = paragraph.paragraph_format
    pf.space_before = Pt(before)
    pf.space_after = Pt(after)
    pf.line_spacing = line


def add_para(doc, text="", *, style=None, bold=False, italic=False, color=None, size=None, after=6):
    p = doc.add_paragraph(style=style)
    set_paragraph_spacing(p, after=after)
    if text:
        r = p.add_run(text)
        set_run_font(r, size=size, color=color, bold=bold, italic=italic)
    return p


def add_bullets(doc, items: list[str]) -> None:
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        set_paragraph_spacing(p, after=4)
        r = p.add_run(item)
        set_run_font(r)


def _find_abstract_num_id(doc: Document, style_id: str) -> str:
    numbering = doc.part.numbering_part.element
    for abstract_num in numbering.findall(qn("w:abstractNum")):
        for p_style in abstract_num.findall(".//" + qn("w:pStyle")):
            if p_style.get(qn("w:val")) == style_id:
                return abstract_num.get(qn("w:abstractNumId"))
    # Word's default template usually maps decimal lists to abstract 7.
    return "7"


def _new_numbering_id(doc: Document, style_id: str = "ListNumber") -> str:
    numbering = doc.part.numbering_part.element
    existing = [
        int(num.get(qn("w:numId")))
        for num in numbering.findall(qn("w:num"))
        if num.get(qn("w:numId")) is not None
    ]
    num_id = str(max(existing or [0]) + 1)
    num = OxmlElement("w:num")
    num.set(qn("w:numId"), num_id)
    abstract = OxmlElement("w:abstractNumId")
    abstract.set(qn("w:val"), _find_abstract_num_id(doc, style_id))
    num.append(abstract)
    override = OxmlElement("w:lvlOverride")
    override.set(qn("w:ilvl"), "0")
    start = OxmlElement("w:startOverride")
    start.set(qn("w:val"), "1")
    override.append(start)
    num.append(override)
    numbering.append(num)
    return num_id


def _apply_numbering(paragraph, num_id: str, level: int = 0) -> None:
    p_pr = paragraph._p.get_or_add_pPr()
    num_pr = p_pr.find(qn("w:numPr"))
    if num_pr is None:
        num_pr = OxmlElement("w:numPr")
        p_pr.append(num_pr)
    ilvl = num_pr.find(qn("w:ilvl"))
    if ilvl is None:
        ilvl = OxmlElement("w:ilvl")
        num_pr.append(ilvl)
    ilvl.set(qn("w:val"), str(level))
    num = num_pr.find(qn("w:numId"))
    if num is None:
        num = OxmlElement("w:numId")
        num_pr.append(num)
    num.set(qn("w:val"), num_id)


def add_numbers(doc, items: list[str]) -> None:
    num_id = _new_numbering_id(doc)
    for item in items:
        p = doc.add_paragraph()
        _apply_numbering(p, num_id)
        set_paragraph_spacing(p, after=4)
        r = p.add_run(item)
        set_run_font(r)


def add_code(doc, code: str) -> None:
    p = doc.add_paragraph(style="Code Block")
    set_paragraph_spacing(p, before=2, after=8, line=1.0)
    p.paragraph_format.keep_together = True
    r = p.add_run(code.strip("\n"))
    set_run_font(r, name="Consolas", size=8.5, color=RGBColor(24, 49, 37))
    p_format = p._p.get_or_add_pPr()
    shd = p_format.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        p_format.append(shd)
    shd.set(qn("w:fill"), "F1F5F3")


def add_callout(doc, title: str, body: str, *, fill: str = LIGHT_GRAY) -> None:
    table = doc.add_table(rows=1, cols=1)
    set_table_fixed(table, [6.25])
    set_cell_margins(table, top=140, bottom=140, start=180, end=180)
    cell = table.cell(0, 0)
    set_cell_shading(cell, fill)
    p = cell.paragraphs[0]
    set_paragraph_spacing(p, after=3)
    r = p.add_run(title)
    set_run_font(r, bold=True, color=DARK_BLUE)
    p2 = cell.add_paragraph()
    set_paragraph_spacing(p2, after=0)
    r2 = p2.add_run(body)
    set_run_font(r2)
    add_para(doc, "", after=4)


def add_figure(doc, image_path: str, caption: str, width: float = 6.25) -> None:
    path = Path(image_path)
    if not path.exists():
        add_callout(
            doc,
            "Screenshot missing",
            f"Expected screenshot was not found at {image_path}. Reinsert it before publishing.",
            fill=PALE_RED,
        )
        return
    doc.add_picture(str(path), width=Inches(width))
    last = doc.paragraphs[-1]
    last.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p = doc.add_paragraph()
    set_paragraph_spacing(p, before=2, after=8)
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(caption)
    set_run_font(r, size=9, color=MUTED, italic=True)


def add_kv_table(doc, rows: list[tuple[str, str]], widths=(1.75, 4.55)) -> None:
    table = doc.add_table(rows=1, cols=2)
    table.style = "Table Grid"
    set_table_fixed(table, list(widths))
    set_cell_margins(table)
    hdr = table.rows[0].cells
    hdr[0].text = "Item"
    hdr[1].text = "Value"
    for cell in hdr:
        set_cell_shading(cell, LIGHT_BLUE)
        for p in cell.paragraphs:
            for r in p.runs:
                set_run_font(r, bold=True)
    for label, value in rows:
        cells = table.add_row().cells
        cells[0].text = label
        cells[1].text = value
        for p in cells[0].paragraphs:
            for r in p.runs:
                set_run_font(r, bold=True)
        for cell in cells:
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
    add_para(doc, "", after=4)


def add_table(doc, headers: list[str], rows: list[list[str]], widths: list[float]) -> None:
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    set_table_fixed(table, widths)
    set_cell_margins(table)
    for idx, header in enumerate(headers):
        cell = table.rows[0].cells[idx]
        cell.text = header
        set_cell_shading(cell, LIGHT_BLUE)
        for p in cell.paragraphs:
            for r in p.runs:
                set_run_font(r, bold=True)
    for row in rows:
        cells = table.add_row().cells
        for idx, value in enumerate(row):
            cells[idx].text = value
            cells[idx].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
    add_para(doc, "", after=4)


def configure_styles(doc: Document) -> None:
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    normal.font.size = Pt(11)
    normal.font.color.rgb = INK
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25

    for name, size, color, before, after in [
        ("Heading 1", 16, BLUE, 18, 10),
        ("Heading 2", 13, BLUE, 14, 7),
        ("Heading 3", 12, DARK_BLUE, 10, 5),
    ]:
        style = styles[name]
        style.font.name = "Calibri"
        style._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
        style._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
        style.font.size = Pt(size)
        style.font.color.rgb = color
        style.font.bold = True
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True

    title = styles["Title"]
    title.font.name = "Calibri"
    title._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    title._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    title.font.size = Pt(23)
    title.font.bold = True
    title.font.color.rgb = INK
    title.paragraph_format.space_after = Pt(4)

    code = styles.add_style("Code Block", 1)
    code.font.name = "Consolas"
    code._element.rPr.rFonts.set(qn("w:ascii"), "Consolas")
    code._element.rPr.rFonts.set(qn("w:hAnsi"), "Consolas")
    code.font.size = Pt(8.5)
    code.paragraph_format.left_indent = Inches(0.08)
    code.paragraph_format.right_indent = Inches(0.08)
    code.paragraph_format.space_before = Pt(2)
    code.paragraph_format.space_after = Pt(8)


def configure_page(doc: Document) -> None:
    section = doc.sections[0]
    section.top_margin = Inches(1.0)
    section.bottom_margin = Inches(1.0)
    section.left_margin = Inches(1.0)
    section.right_margin = Inches(1.0)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    header = section.header.paragraphs[0]
    header.text = "Oracle AI Database 26ai Deep Data Security AI Agent Demo"
    header.alignment = WD_ALIGN_PARAGRAPH.LEFT
    for run in header.runs:
        set_run_font(run, size=9, color=MUTED)

    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    footer.text = "Prepared for demo build - placeholders only, no secrets"
    for run in footer.runs:
        set_run_font(run, size=9, color=MUTED)


def add_cover(doc: Document) -> None:
    add_para(doc, "Technical Runbook", bold=True, color=MUTED, size=11, after=8)
    title = doc.add_paragraph(style="Title")
    title.add_run("Oracle AI Database 26ai Deep Data Security AI Agent Demo")
    subtitle = add_para(
        doc,
        "Baby-step setup guide for OCI DBaaS, OCI Identity Domain, TCPS, Python Flask, and Deep Data Security",
        color=MUTED,
        size=13,
        after=16,
    )
    subtitle.alignment = WD_ALIGN_PARAGRAPH.LEFT
    add_kv_table(
        doc,
        [
            ("Audience", "OCI admins, database admins, security architects, and non-coding technical users"),
            ("Demo users", "Alex as manager, Indira as employee"),
            ("Current status", "Alex manager flow and Indira employee flow tested through the public demo URL."),
            ("Security note", "This document uses placeholders. Do not paste real passwords, client secrets, or private keys into a public version."),
            ("Date", date.today().isoformat()),
        ],
    )
    add_callout(
        doc,
        "Executive takeaway",
        "The AI agent can request a broad HR query, but Oracle AI Database 26ai applies Deep Data Security using the signed-in user's identity and OCI IAM groups. The database returns only allowed rows and cells.",
        fill=PALE_GREEN,
    )


def build_doc() -> Document:
    doc = Document()
    configure_page(doc)
    configure_styles(doc)
    add_cover(doc)

    doc.add_heading("1. What This Demo Proves", level=1)
    add_para(
        doc,
        "This demo shows a secure pattern for AI agents that query enterprise data. The agent may ask for too much data, but Oracle AI Database 26ai enforces the real user's data boundary using Deep Data Security.",
    )
    add_bullets(
        doc,
        [
            "Alex signs in through OCI IAM as a manager.",
            "Indira signs in through OCI IAM as an employee.",
            "Both users use the same Python AI-agent web application.",
            "The application connects to the database using one service account, AI_AGENT_SVC.",
            "The database receives the real end-user token and applies data grants.",
            "The same broad prompt returns different allowed results.",
        ]
    )
    add_table(
        doc,
        ["User", "Role", "Prompt", "Expected protected result"],
        [
            ["Alex", "Manager", "show me every employee salary and ssn", "Own row plus direct reports. SSN hidden for direct reports."],
            ["Indira", "Employee", "show me every employee salary and ssn", "Indira's own row only. No access to other employees."],
        ],
        [1.0, 1.0, 2.35, 1.95],
    )

    doc.add_heading("2. Before Deep Data Security", level=1)
    add_para(
        doc,
        "Before Deep Data Security, a normal application often connects to the database with one shared service account. The database sees the service account, not the real human user. Any per-user filtering must be done in application code.",
    )
    add_code(
        doc,
        """
User prompt
  -> AI agent web app
  -> shared DB service account
  -> broad SELECT on HR.EMPLOYEES
  -> application code tries to filter the result
""",
    )
    add_callout(
        doc,
        "Baseline risk",
        "If the application exposes a broad tool, misses a filter, or is affected by prompt injection, the service account may retrieve data the user should not receive. The database has no final identity-aware boundary unless end-user context is propagated.",
        fill=PALE_RED,
    )
    add_table(
        doc,
        ["Scenario", "Without database-native policy"],
        [
            ["Alex asks for all salary and SSN", "The shared service account may return all employees and sensitive columns if application logic does not filter correctly."],
            ["Indira asks for all salary and SSN", "The same broad account may return too much data, even though Indira is not a manager."],
        ],
        [2.0, 4.3],
    )

    doc.add_heading("3. After Deep Data Security", level=1)
    add_para(
        doc,
        "After Deep Data Security, the database validates OCI IAM tokens, builds ORA_END_USER_CONTEXT, activates mapped data roles, and applies data grants at query time. The service account is no longer the authorization boundary.",
    )
    add_code(
        doc,
        """
OCI IAM user login with MFA
  -> Python Flask AI-agent app
  -> end-user access token + app database access token
  -> TCPS connection as AI_AGENT_SVC
  -> create end-user security context
  -> Oracle AI Database applies Deep Data Security data grants
  -> only allowed rows and columns are returned
""",
    )
    add_table(
        doc,
        ["User", "Token group claim", "Deep Data Security role activation", "Output after policy"],
        [
            ["Alex", "DeepSec_Manager, DeepSec_Employee", "hrapp_iam_managers and hrapp_iam_employees", "Four rows: Alex plus direct reports. Direct-report SSN masked."],
            ["Indira", "DeepSec_Employee", "hrapp_iam_employees", "One row: Indira Darshni only. Other HR rows not returned."],
        ],
        [0.9, 1.8, 1.9, 1.7],
    )

    doc.add_heading("4. Target Architecture", level=1)
    add_para(doc, "The demo uses these components.")
    add_kv_table(
        doc,
        [
            ("OCI Base DBaaS", "Oracle AI Database 26ai PDB with TCPS listener on port 2484."),
            ("OCI Identity Domain", "Authenticates users, issues access tokens, and adds a group claim."),
            ("DB Resource app", "Represents the database as an OAuth resource server and defines the database scope."),
            ("AI Agent Client app", "Represents the Python web app. Uses Authorization Code + PKCE and Client Credentials."),
            ("OCI Compute", "Runs the Python Flask demo app. Connects privately to DBaaS over TCPS."),
            ("Python app", "Receives the user token, obtains the app DB token, and sets end-user security context."),
            ("Deep Data Security", "Enforces data roles and grants on HR.EMPLOYEES."),
            ("Data Safe", "Optional audit view showing AI_AGENT_SVC activity and SQL access trail."),
        ],
    )

    doc.add_heading("5. Prerequisites", level=1)
    add_bullets(
        doc,
        [
            "OCI tenancy access with permission to create or use a Base Database Service DB system.",
            "A compartment for the lab, for example root/bigplatform/AlexKovuru.",
            "A VCN and subnet where the compute instance can reach the DB private IP on port 2484.",
            "An OCI Compute instance running Oracle Linux, used as the Python app host.",
            "Identity Domain admin help for Integrated Applications and custom claims.",
            "SQLPlus or SQLcl access to the 26ai PDB.",
            "A private key for SSH to the compute instance and, if allowed, DB host.",
            "No real passwords or client secrets in screenshots, documents, or public blogs.",
        ]
    )

    doc.add_heading("6. Create the 26ai DBaaS Database", level=1)
    add_para(doc, "If you already have the database, use this section only as a checklist.")
    add_numbers(
        doc,
        [
            "Open OCI Console and select the correct region and compartment.",
            "Go to Oracle Database, then Base Database Service.",
            "Choose Create DB system.",
            "Select a VM DB system shape suitable for a demo.",
            "Choose or create a VCN and subnet reachable from your compute instance.",
            "Set the database name, for example DB26AI.",
            "Set the PDB name, for example DB26AI_PDB1.",
            "Choose Oracle AI Database 26ai or the available 23.26.x 26ai release.",
            "Set the admin password and keep it in a secure vault.",
            "Create the DB system and wait until it is available.",
        ]
    )
    add_callout(
        doc,
        "Network recommendation",
        "For a client-facing demo, keep the database listener private and run the Python app from an OCI Compute instance in the same VCN. Use an SSH tunnel from your laptop to the Flask app instead of opening port 8091 to the internet.",
    )

    doc.add_heading("7. Verify DB Listener and TCPS", level=1)
    add_para(doc, "On the DB host, confirm that the database listener exposes TCPS on port 2484.")
    add_code(
        doc,
        """
ssh opc@<db-host-public-or-bastion-ip>
sudo su - oracle
lsnrctl status
""",
    )
    add_para(doc, "Look for an endpoint similar to:")
    add_code(
        doc,
        """
(DESCRIPTION=(ADDRESS=(PROTOCOL=tcps)(HOST=<db-private-ip>)(PORT=2484)))
""",
    )
    add_para(doc, "From the compute instance, verify network reachability without installing nc:")
    add_code(
        doc,
        """
timeout 5 bash -c '</dev/tcp/<db-private-ip>/2484' && echo "2484 OPEN" || echo "2484 BLOCKED"
""",
    )

    doc.add_heading("8. Retrieve the DBaaS TLS Certificate", level=1)
    add_para(
        doc,
        "Python Thin mode needs to trust the DB TCPS certificate. DBaaS commonly stores the TCPS wallet under /opt/oracle/dcs/commonstore/tcps_wallet.",
    )
    add_numbers(
        doc,
        [
            "SSH to the DB host.",
            "Switch to oracle or grid, depending on where the network files are readable.",
            "Find the wallet location in sqlnet.ora.",
            "Display the wallet certificate DN.",
            "Export the server certificate to a PEM/CER file.",
            "Copy that file to the compute instance.",
        ]
    )
    add_code(
        doc,
        """
sudo su - oracle
cat /u01/app/23.0.0.0/grid/network/admin/sqlnet.ora
ls -l /opt/oracle/dcs/commonstore/tcps_wallet

orapki wallet display -wallet /opt/oracle/dcs/commonstore/tcps_wallet

orapki wallet export \\
  -wallet /opt/oracle/dcs/commonstore/tcps_wallet \\
  -dn "CN=<certificate-common-name>" \\
  -cert /tmp/db26ai_tcps_server_cert.pem

openssl x509 \\
  -in /tmp/db26ai_tcps_server_cert.pem \\
  -noout -subject -issuer -dates -fingerprint -sha256
""",
    )
    add_para(doc, "On your laptop or compute instance, copy the certificate. Example:")
    add_code(
        doc,
        """
scp opc@<db-host>:/tmp/db26ai_tcps_server_cert.pem .
scp db26ai_tcps_server_cert.pem opc@<compute-public-ip>:/home/opc/
""",
    )
    add_para(doc, "On the compute instance:")
    add_code(
        doc,
        """
mkdir -p /home/opc/db26ai_tcps_wallet
cp /home/opc/db26ai_tcps_server_cert.pem /home/opc/db26ai_tcps_wallet/ewallet.pem
chmod 600 /home/opc/db26ai_tcps_wallet/ewallet.pem
""",
    )

    doc.add_heading("9. Create OCI Identity Domain Applications", level=1)
    doc.add_heading("9.1 DB Resource Application", level=2)
    add_numbers(
        doc,
        [
            "Go to Identity and Security, Domains, Default domain, Integrated applications.",
            "Create a Confidential Application named DB26AI_Resource.",
            "Enable Resource server configuration.",
            "Set Primary audience to a stable database resource value, for example https://db26ai:2484/DB26AI_PDB1.",
            "Add a scope named all.",
            "Record the Application ID. This is used in the database identity_provider_oauth_config app_id field.",
            "Record the Client ID and Client Secret. These are used when the database creates the OCI_IAM_DOMAIN_DB_CRED$ credential.",
        ]
    )
    add_callout(
        doc,
        "Important",
        "The database identity provider app_id is the DB Resource application's Application ID, not the OAuth Client ID.",
        fill=PALE_RED,
    )
    doc.add_heading("9.2 AI Agent Client Application", level=2)
    add_numbers(
        doc,
        [
            "Create another Confidential Application named DeepSec AI Agent Client.",
            "Enable Client configuration.",
            "Select Authorization code and Client credentials grant types.",
            "For the current public-IP demo, set Redirect URL to http://132.145.40.89:8091/callback.",
            "Set Post-logout redirect URL to http://132.145.40.89:8091.",
            "Enable Allow non-HTTPS URLs for the lab only. For production, use HTTPS with a real DNS name and certificate.",
            "In Token issuance policy, add the DB Resource application and the all scope.",
            "Record the AI Agent Client OAuth Client ID and Client Secret. These go in the Python .env file.",
        ]
    )
    add_para(doc, "The full database scope should look like this:")
    add_code(doc, "https://db26ai:2484/DB26AI_PDB1all")

    doc.add_heading("10. Create OCI IAM Users, Groups, and Custom Claim", level=1)
    add_numbers(
        doc,
        [
            "Create or identify the OCI IAM user for Alex.",
            "Create or identify the OCI IAM user for Indira.",
            "Create group DeepSec_Manager.",
            "Create group DeepSec_Employee.",
            "Add Alex to DeepSec_Manager and DeepSec_Employee.",
            "Add Indira to DeepSec_Employee.",
            "Make sure the username that reaches the database matches HR.EMPLOYEES.USER_NAME: alexk and indiradarshni.",
        ]
    )
    add_para(doc, "Ask the Identity Domain admin to create this custom access-token claim:")
    add_code(
        doc,
        """
curl -i -X POST "$DOMAIN/admin/v1/CustomClaims" \\
  -H "Authorization: Bearer $ACCESS_TOKEN" \\
  -H "Content-Type: application/scim+json" \\
  -d '{
    "schemas": [
      "urn:ietf:params:scim:schemas:oracle:idcs:CustomClaim"
    ],
    "name": "group",
    "value": "$user.groups.*.display",
    "expression": true,
    "mode": "always",
    "tokenType": "AT",
    "allScopes": true
  }'
""",
    )
    add_callout(
        doc,
        "Common mistake",
        "The claim name must be group. A claim named user_groups may appear in the token but Deep Data Security will not activate IAM_OAUTH_GROUP mapped roles from it.",
        fill=PALE_RED,
    )
    add_para(doc, "Verify the claim:")
    add_code(
        doc,
        """
curl -sS -X GET "$DOMAIN/admin/v1/CustomClaims" \\
  -H "Authorization: Bearer $ACCESS_TOKEN" \\
  -H "Accept: application/json" \\
| jq '.Resources[] | select(.name=="group")'
""",
    )

    doc.add_heading("11. Configure the Database to Trust OCI IAM", level=1)
    add_para(doc, "Run as SYS or another account allowed to alter identity provider settings in the target PDB.")
    add_code(
        doc,
        """
sqlplus "/ as sysdba"
ALTER SESSION SET CONTAINER=<target_pdb>;

@sql/11_configure_oci_iam_safe.sql \\
  "https://<idcs-domain>.identity.oraclecloud.com:443" \\
  "<db-resource-application-id>" \\
  "<db-resource-client-id>" \\
  "<db-resource-client-secret>"
""",
    )
    add_para(doc, "Verify:")
    add_code(
        doc,
        """
SHOW PARAMETER identity_provider
""",
    )

    doc.add_heading("12. Create Demo Schema and Deep Data Security Policy", level=1)
    add_para(doc, "Run the setup script as deepsec_admin. Use placeholders in documentation and store real passwords securely.")
    add_code(
        doc,
        """
sqlplus deepsec_admin/<password>@<pdb-service>

@sql/20_setup_hr_demo.sql \\
  "<end-user-password>" \\
  "<agent-service-password>" \\
  "<ai-agent-client-id>"
""",
    )
    add_para(
        doc,
        "If the base script creates Emma and Marvin, rename the business demo rows to Alex and Indira and rebuild the manager lookup table.",
    )
    add_code(
        doc,
        """
UPDATE hr.employees
SET first_name = 'Alex',
    last_name = 'Kovuru',
    user_name = 'alexk'
WHERE employee_id = 2;

UPDATE hr.employees
SET first_name = 'Indira',
    last_name = 'Darshni',
    user_name = 'indiradarshni'
WHERE employee_id = 3;

TRUNCATE TABLE hr.managers;

INSERT INTO hr.managers (manager_id, employee_id, mgr_user_name, mgr_first_name, mgr_last_name)
SELECT e.manager_id,
       e.employee_id,
       m.user_name,
       m.first_name,
       m.last_name
FROM hr.employees e
JOIN hr.employees m
  ON e.manager_id = m.employee_id
WHERE e.manager_id IS NOT NULL;

COMMIT;
""",
    )

    doc.add_heading("13. Add IAM Group-Mapped Data Roles", level=1)
    add_para(
        doc,
        "Run this after the group claim is working or before final testing. The roles will activate only when the token contains matching OCI IAM group display names.",
    )
    add_code(
        doc,
        """
CREATE DATA ROLE hrapp_iam_employees
  MAPPED TO 'IAM_OAUTH_GROUP=DeepSec_Employee';

CREATE DATA ROLE hrapp_iam_managers
  MAPPED TO 'IAM_OAUTH_GROUP=DeepSec_Manager';

CREATE OR REPLACE DATA GRANT hr.hrapp_iam_employee_access
AS SELECT, UPDATE(phone_number, first_name)
ON hr.employees
WHERE upper(user_name) = upper(ORA_END_USER_CONTEXT.username)
TO hrapp_iam_employees;

CREATE OR REPLACE DATA GRANT hr.hrapp_iam_manager_access
AS SELECT (ALL COLUMNS EXCEPT ssn),
   UPDATE (salary, department_id, first_name)
ON hr.employees
WHERE manager_id IN (
  SELECT m.manager_id
  FROM hr.managers m
  WHERE upper(m.mgr_user_name) = upper(ORA_END_USER_CONTEXT.username)
)
TO hrapp_iam_managers;
""",
    )
    add_para(doc, "Verify metadata:")
    add_code(
        doc,
        """
SELECT data_role, role_type, grantee, grantee_type
FROM dba_data_role_grants
WHERE grantee IN ('ALEXK','INDIRA')
ORDER BY grantee, data_role;

SELECT data_role, role_type
FROM dba_data_roles
WHERE data_role LIKE 'HRAPP_IAM%';

SELECT grant_name, grantee, privilege, column_name
FROM dba_data_grants
WHERE object_owner = 'HR'
  AND object_name = 'EMPLOYEES'
ORDER BY grant_name, grantee, privilege, column_name;
""",
    )

    doc.add_heading("14. Prepare the Python Web App on OCI Compute", level=1)
    add_numbers(
        doc,
        [
            "SSH to the compute instance as opc.",
            "Confirm Python 3.9 or newer is available.",
            "Create a virtual environment.",
            "Copy or extract the Deep_Data_Security-AI-Security-Agent runtime bundle.",
            "Install requirements and the local package.",
        ]
    )
    add_code(
        doc,
        """
ssh opc@<compute-public-ip>
python3 --version

python3 -m venv ~/.venv
source ~/.venv/bin/activate

tar -xzf ~/deepsec-agent-demo-runtime.tar.gz -C ~/Deep_Data_Security-AI-Security-Agent
cd ~/Deep_Data_Security-AI-Security-Agent

python -m pip install -r requirements.txt
python -m pip install -e .
""",
    )

    doc.add_heading("15. Create the Compute .env File", level=1)
    add_para(doc, "Create ~/Deep_Data_Security-AI-Security-Agent/.env with placeholder values replaced by real secure values.")
    add_code(
        doc,
        """
ORACLE_DSN=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCPS)(HOST=<db-private-ip>)(PORT=2484))(CONNECT_DATA=(SERVICE_NAME=<pdb-service-name>))(SECURITY=(SSL_SERVER_DN_MATCH=NO)))
ORACLE_USER=AI_AGENT_SVC
ORACLE_PASSWORD=<agent-service-password>
ORACLE_WALLET_LOCATION=/home/opc/db26ai_tcps_wallet
ORACLE_THICK_MODE=false

OCI_DOMAIN_URL=https://<idcs-domain>.identity.oraclecloud.com:443
OCI_APP_CLIENT_ID=<ai-agent-client-client-id>
OCI_APP_CLIENT_SECRET=<ai-agent-client-secret>
OCI_DB_SCOPE=https://db26ai:2484/DB26AI_PDB1all
OCI_APP_SCOPE=https://db26ai:2484/DB26AI_PDB1all

WEB_BASE_URL=http://132.145.40.89:8091
WEB_REDIRECT_URI=http://132.145.40.89:8091/callback
FLASK_SECRET_KEY=<random-long-value>
""",
    )
    add_callout(
        doc,
        "Why Thin mode",
        "Keep ORACLE_THICK_MODE=false. The Python Thin driver path is used for create_end_user_security_context and TCPS token propagation in this demo.",
    )

    doc.add_heading("16. Run the Web Demo", level=1)
    add_para(doc, "For the smooth management demo, run the app on the compute instance and open the public demo URL from the browser. Keep this lab exposure time-boxed and restricted by security list/NSG source IPs where possible.")
    add_para(doc, "On the compute instance:")
    add_code(
        doc,
        """
cd ~/Deep_Data_Security-AI-Security-Agent
source ~/.venv/bin/activate
python -m deepsec_agent_demo web --host 0.0.0.0 --port 8091
""",
    )
    add_para(doc, "On the demo browser, open:")
    add_code(doc, "http://132.145.40.89:8091/login")
    add_callout(
        doc,
        "Safer alternate path",
        "For internal testing, you can still use an SSH tunnel: ssh -L 8091:localhost:8091 opc@<compute-public-ip>, then configure redirect URLs as http://localhost:8091/callback and http://localhost:8091.",
        fill=LIGHT_GRAY,
    )

    doc.add_heading("17. Test Alex Manager Flow", level=1)
    add_numbers(
        doc,
        [
            "Open the demo page in incognito/private browser.",
            "Click Login with OCI IAM.",
            "Login as Alex and complete MFA.",
            "Confirm the group row shows DeepSec_Manager and DeepSec_Employee.",
            "Enter show me every employee salary and ssn.",
            "Click Run Query.",
        ]
    )
    add_table(
        doc,
        ["Expected Alex result", "Meaning"],
        [
            ["Rows: Alex, Indira, Charlie, Dana", "Alex is manager of those direct reports."],
            ["Alex SSN visible", "Alex also has employee role for his own row."],
            ["Direct-report SSN blank/null", "Manager data grant excludes SSN."],
            ["Salary visible", "Manager data grant allows salary for direct reports."],
        ],
        [2.4, 3.9],
    )
    add_figure(
        doc,
        "/Users/akovuru/Desktop/Screen_Shots/Screenshot 2026-06-24 at 1.22.21 AM.png",
        "Alex manager test: same broad SQL, but only Alex and direct reports are returned. Direct-report SSNs are blank.",
    )

    doc.add_heading("18. Test Indira Employee Flow", level=1)
    add_numbers(
        doc,
        [
            "Click Logout in the demo app.",
            "Use a fresh incognito window or clear OCI/localhost cookies.",
            "Login with Indira's OCI IAM account and complete MFA.",
            "Confirm the group row shows DeepSec_Employee and not DeepSec_Manager.",
            "Enter show me every employee salary and ssn.",
            "Click Run Query.",
        ]
    )
    add_table(
        doc,
        ["Expected Indira result", "Meaning"],
        [
            ["One row only: Indira Darshni", "Employee grant allows only own HR row."],
            ["No Alex, Charlie, Dana, Bob, Fiona, or Grace rows", "Indira has no manager role."],
            ["If more rows appear", "Check group claim, data role mapping, and mandatory data grant enforcement."],
        ],
        [2.4, 3.9],
    )
    add_figure(
        doc,
        "/Users/akovuru/Desktop/Screen_Shots/Screenshot 2026-06-24 at 1.16.11 PM.png",
        "Indira employee test: the same overpull prompt returns only Indira's own HR row.",
    )

    doc.add_heading("19. Advanced Before-and-After Use Case: New Joiners", level=1)
    add_para(
        doc,
        "Use this extension when you want a more dramatic client-facing story. Anuj joins as a manager and Avinash joins as an employee. Both can authenticate through OCI IAM and use the same AI agent prompt.",
    )
    add_callout(
        doc,
        "Recommended demo framing",
        "Show the before state only in a lab baseline path. In a secure production design, users without Deep Data Security role mapping should be denied or see no rows. The risky before state is useful for teaching why database-native policy matters, but it should not be the production operating mode.",
        fill=PALE_RED,
    )
    add_table(
        doc,
        ["Stage", "Anuj manager", "Avinash employee", "Teaching point"],
        [
            ["Before DDS", "Same broad service-account result in a lab baseline route, or no rows in strict default-deny mode.", "Same broad service-account result in a lab baseline route, or no rows in strict default-deny mode.", "Application-only authorization is fragile; default-deny is safer but not role-aware until configured."],
            ["After DDS", "Own row plus direct reports; restricted columns based on manager grant.", "Own row only.", "Same prompt and same SQL become role-aware inside the database."],
        ],
        [1.0, 1.8, 1.8, 1.7],
    )
    add_para(doc, "If you add the two users to the current demo, align the OCI IAM usernames and HR.EMPLOYEES.USER_NAME values exactly.")
    add_code(
        doc,
        """
-- Example only. Replace usernames with the actual OCI IAM usernames in the access token.
INSERT INTO hr.employees VALUES
  (8, 'Anuj', 'Manager', 'SWE_MGR', 1, '888-88-8888', NULL, '555-100-0008', 170000, 'anuj', 1);

INSERT INTO hr.employees VALUES
  (9, 'Avinash', 'Employee', 'SWE1', 1, '999-99-9999', NULL, '555-100-0009', 90000, 'avinash', 8);

DELETE FROM hr.managers;

INSERT INTO hr.managers (manager_id, employee_id, mgr_user_name, mgr_first_name, mgr_last_name)
SELECT e.manager_id, e.employee_id, m.user_name, m.first_name, m.last_name
FROM hr.employees e
JOIN hr.employees m
  ON e.manager_id = m.employee_id
WHERE e.manager_id IS NOT NULL;

COMMIT;
""",
    )
    add_bullets(
        doc,
        [
            "Before policy assignment, capture the baseline behavior with the same prompt: show me every employee salary and ssn.",
            "Then add Anuj to DeepSec_Manager and DeepSec_Employee, and Avinash to DeepSec_Employee.",
            "If you reuse the existing group-mapped roles, no new data roles are needed.",
            "Run the same prompt again and compare the result set.",
        ]
    )

    doc.add_heading("20. Show Data Safe Audit Evidence", level=1)
    add_para(doc, "If Data Safe Activity Auditing is enabled, use it as the audit proof.")
    add_bullets(
        doc,
        [
            "Filter by database user AI_AGENT_SVC.",
            "Look for SQL touching HR.EMPLOYEES.",
            "Use module/action if visible: DeepSecAIAgentDemo and attempt_overpull.",
            "Explain that one service account connected, but Deep Data Security enforced Alex or Indira's effective data boundary.",
        ]
    )

    doc.add_heading("21. Troubleshooting", level=1)
    add_table(
        doc,
        ["Symptom", "Likely cause", "Fix"],
        [
            ["group is blank", "Custom claim missing, named user_groups, old token, or user has no group", "Create claim named group, use incognito, login again, verify OCI IAM group assignment."],
            ["ORA-00942 on HR.EMPLOYEES", "No active data role or mandatory grants block service account", "Confirm group claim, IAM mapped roles, data grants, and group names match exactly."],
            ["ORA-52601 token expired", "OCI IAM access token timed out", "Logout and login again."],
            ["ORA-52602 token parse/verify error", "Wrong app_id or domain_url in DB config", "Use DB Resource Application ID and include :443 in domain URL."],
            ["invalid_scope", "Wrong OCI_DB_SCOPE", "Use full DB resource scope, for example https://db26ai:2484/DB26AI_PDB1all."],
            ["TCPS timeout", "Network security rule or private IP path issue", "Verify compute can reach DB private IP port 2484."],
            ["Shell says malformed URL", "Smart quotes pasted into curl", "Use plain ASCII quotes only."],
        ],
        [1.45, 2.1, 2.75],
    )

    doc.add_heading("22. Demo Script for Management", level=1)
    add_numbers(
        doc,
        [
            "Start with the baseline risk: a shared AI service account can ask for too much.",
            "Show Alex login through OCI IAM with MFA.",
            "Show the group claim contains DeepSec_Manager and DeepSec_Employee.",
            "Run show me every employee salary and ssn.",
            "Point out that the SQL asked for SSN, but direct-report SSN is masked.",
            "Logout and login as Indira.",
            "Run the same prompt.",
            "Point out that Indira receives only her own row.",
            "Optional advanced story: show Anuj and Avinash before policy assignment, then after group and data-role mapping.",
            "Close with the message: same prompt, same table, same app, different allowed result.",
        ]
    )

    doc.add_heading("23. Public Blog Sanitization Checklist", level=1)
    add_bullets(
        doc,
        [
            "Replace public IPs, private IPs, domain IDs, client IDs, and usernames if they reveal sensitive information.",
            "Never include client secrets, database passwords, private keys, or real recovery emails.",
            "Crop screenshots to hide browser profile icons, tenancy OCIDs, and private compartment names if needed.",
            "Use placeholders such as <identity-domain-url>, <client-id>, <db-private-ip>, and <pdb-service-name>.",
            "For public publication, replace the lab public IP with a neutral hostname or placeholder.",
        ]
    )

    doc.add_heading("24. Source Notes", level=1)
    add_bullets(
        doc,
        [
            "Oracle Identity Domains custom claims documentation: https://docs.oracle.com/en-us/iaas/Content/Identity/api-getstarted/custom-claims-token.htm",
            "Ricardo Gutierrez Medium article: Building Production Web Apps with Oracle Deep Data Security and OCI IAM.",
            "Local project files: README.md, DEMO_SETUP_GUIDE.md, sql/*.sql, and src/deepsec_agent_demo/*.py.",
        ]
    )

    return doc


def main() -> None:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc = build_doc()
    doc.save(OUT)
    print(OUT)


if __name__ == "__main__":
    main()
