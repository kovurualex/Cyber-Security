import fs from "node:fs/promises";
import path from "node:path";
import {
  ensureArtifactToolWorkspace,
  importArtifactTool,
  saveBlobToFile,
} from "/Users/akovuru/.codex/plugins/cache/openai-primary-runtime/presentations/26.623.12021/skills/presentations/container_tools/artifact_tool_utils.mjs";

const WORKSPACE = "/private/tmp/codex-presentations/manual-deepsec/demo-flow-20260624";
const TMP_DIR = path.join(WORKSPACE, "tmp");
const PREVIEW_DIR = path.join(TMP_DIR, "preview");
const LAYOUT_DIR = path.join(TMP_DIR, "layout");
const QA_DIR = path.join(TMP_DIR, "qa");
const OUTPUT_DIR = "/Users/akovuru/Documents/Deep_Data_Security-AI-Security-Agent/outputs";
const FINAL_PPTX = path.join(OUTPUT_DIR, "deep-data-security-ai-agent-demo-flow.pptx");

const ALEX_SCREEN =
  "/Users/akovuru/Desktop/Screen_Shots/Screenshot 2026-06-24 at 1.22.21 AM.png";
const INDIRA_SCREEN =
  "/Users/akovuru/Desktop/Screen_Shots/Screenshot 2026-06-24 at 1.16.11 PM.png";

await ensureArtifactToolWorkspace(WORKSPACE);
const { Presentation, PresentationFile } = await importArtifactTool(WORKSPACE);

await fs.mkdir(PREVIEW_DIR, { recursive: true });
await fs.mkdir(LAYOUT_DIR, { recursive: true });
await fs.mkdir(QA_DIR, { recursive: true });
await fs.mkdir(OUTPUT_DIR, { recursive: true });

await fs.writeFile(
  path.join(TMP_DIR, "source-notes.txt"),
  [
    "Source notes",
    "",
    "Deck content is based on the user's live Oracle AI Database 26ai Deep Data Security demo.",
    "Screenshots used as proof points: Alex manager public-IP result and Indira employee public-IP result.",
    "Advanced Anuj/Avinash scenario is framed as an optional lab-only before/after extension.",
  ].join("\n"),
  "utf8",
);

const W = 1280;
const H = 720;
const C = {
  bg: "#F7F3EC",
  ink: "#18221C",
  muted: "#4F5A52",
  sage: "#2E7D54",
  sageLight: "#E6F0E8",
  oxide: "#A33A2B",
  oxideLight: "#F3E4DF",
  line: "#C9D2CB",
  white: "#FFFDF8",
  gold: "#B8842D",
  blue: "#2F6F9F",
};

const deck = Presentation.create({ slideSize: { width: W, height: H } });

async function imageBlob(imagePath) {
  const bytes = await fs.readFile(imagePath);
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}

function addText(slide, text, x, y, w, h, style = {}) {
  const shape = slide.shapes.add({
    geometry: "textbox",
    position: { left: x, top: y, width: w, height: h },
    fill: "none",
    line: { style: "solid", fill: "none", width: 0 },
  });
  shape.text = text;
  shape.text.style = {
    typeface: style.typeface || "Aptos",
    fontSize: style.fontSize || 22,
    bold: Boolean(style.bold),
    color: style.color || C.ink,
    alignment: style.alignment || "left",
  };
  return shape;
}

function addBox(slide, name, x, y, w, h, fill = C.white, line = C.line, radius = "rounded-lg") {
  return slide.shapes.add({
    geometry: "roundRect",
    name,
    position: { left: x, top: y, width: w, height: h },
    fill,
    line: { style: "solid", fill: line, width: 1.2 },
    borderRadius: radius,
  });
}

function addBadge(slide, text, x, y, w, fill, color = "white") {
  const badge = addBox(slide, `badge-${text}`, x, y, w, 34, fill, fill, "rounded-full");
  badge.text = text;
  badge.text.style = {
    typeface: "Aptos",
    fontSize: 16,
    bold: true,
    color,
    alignment: "center",
  };
  return badge;
}

function addArrow(slide, x1, y1, x2, y2, color = C.muted) {
  return slide.shapes.add({
    geometry: "line",
    position: { left: x1, top: y1, width: x2 - x1, height: y2 - y1 },
    fill: "none",
    line: { style: "solid", fill: color, width: 2.5 },
    head: { type: "triangle", width: "sm", length: "sm" },
  });
}

function addFooter(slide, text) {
  addText(slide, text, 64, 668, 1152, 28, {
    fontSize: 16,
    bold: true,
    color: C.muted,
  });
}

function addTitle(slide, title, subtitle = "") {
  addText(slide, title, 58, 40, 1120, 58, {
    typeface: "Aptos Display",
    fontSize: 38,
    bold: true,
  });
  if (subtitle) {
    addText(slide, subtitle, 60, 96, 1040, 36, {
      fontSize: 20,
      color: C.muted,
    });
  }
}

function addMiniTable(slide, headers, rows, x, y, widths, rowH = 58) {
  const totalW = widths.reduce((a, b) => a + b, 0);
  addBox(slide, "table-header", x, y, totalW, 48, C.ink, C.ink, "rounded-none");
  let cx = x;
  headers.forEach((header, i) => {
    addText(slide, header, cx + 14, y + 12, widths[i] - 24, 26, {
      fontSize: 17,
      bold: true,
      color: "#DDE5DE",
    });
    cx += widths[i];
  });
  rows.forEach((row, r) => {
    const ry = y + 48 + r * rowH;
    addBox(slide, `table-row-${r}`, x, ry, totalW, rowH, C.white, C.line, "rounded-none");
    let tx = x;
    row.forEach((cell, i) => {
      addText(slide, cell, tx + 14, ry + 12, widths[i] - 24, rowH - 16, {
        fontSize: 17,
        color: i === 0 ? C.ink : C.muted,
        bold: i === 0,
      });
      tx += widths[i];
    });
  });
}

{
  const slide = deck.slides.add();
  slide.background.fill = C.bg;
  addTitle(
    slide,
    "Deep Data Security for AI Agents",
    "Same prompt. Same SQL. Same HR table. Different allowed result."
  );
  addText(
    slide,
    "Demo URL",
    72,
    190,
    160,
    32,
    { fontSize: 22, bold: true, color: C.muted }
  );
  addText(
    slide,
    "http://132.145.40.89:8091/login",
    72,
    230,
    720,
    48,
    { fontSize: 30, bold: true, color: C.blue }
  );
  addBox(slide, "takeaway", 72, 330, 1030, 142, C.sageLight, C.sage);
  addText(
    slide,
    "The agent can ask for too much. Oracle AI Database 26ai enforces what the signed-in user is allowed to receive.",
    104,
    364,
    950,
    72,
    { fontSize: 30, bold: true, color: C.ink }
  );
  addFooter(slide, "Audience message: move the final data boundary from prompt/application logic into declarative SQL policy.");
}

{
  const slide = deck.slides.add();
  slide.background.fill = C.bg;
  addTitle(slide, "Secure AI-agent flow", "OCI IAM authenticates the user; the database enforces the allowed result.");
  const y = 180;
  const boxW = 236;
  const gap = 52;
  const xs = [72, 72 + boxW + gap, 72 + (boxW + gap) * 2, 72 + (boxW + gap) * 3];
  const steps = [
    ["1", "OCI IAM login", "Alex or Indira signs in with MFA."],
    ["2", "Python AI app", "Receives user token and obtains app DB token."],
    ["3", "Same SQL tool", "Agent plans the same broad HR query."],
    ["4", "Oracle 26ai DDS", "Rows and cells are filtered by data grants."],
  ];
  steps.forEach(([n, title, body], i) => {
    addBox(slide, `flow-${n}`, xs[i], y, boxW, 170, i === 3 ? C.sageLight : C.white);
    addBadge(slide, n, xs[i] + 18, y + 18, 38, i === 3 ? C.sage : C.blue);
    addText(slide, title, xs[i] + 66, y + 18, boxW - 80, 30, { fontSize: 22, bold: true });
    addText(slide, body, xs[i] + 20, y + 72, boxW - 40, 70, { fontSize: 18, color: C.muted });
    if (i < 3) addArrow(slide, xs[i] + boxW + 8, y + 85, xs[i + 1] - 10, y + 85);
  });
  addMiniTable(
    slide,
    ["Component", "Role in demo"],
    [
      ["OCI Identity Domain", "Issues user token with group claim."],
      ["Compute + Python", "Hosts the web agent and propagates end-user context."],
      ["DBaaS 26ai", "Validates tokens and applies SQL data grants."],
    ],
    120,
    440,
    [300, 740],
    58
  );
  addFooter(slide, "The app connects as AI_AGENT_SVC, but authorization follows the signed-in user.");
}

{
  const slide = deck.slides.add();
  slide.background.fill = C.bg;
  addTitle(slide, "Before vs after Deep Data Security", "The demo contrast: service-account risk versus database-native policy.");
  addBox(slide, "before", 86, 168, 520, 356, C.oxideLight, C.oxide);
  addText(slide, "Before DDS", 116, 204, 300, 44, { fontSize: 32, bold: true, color: C.oxide });
  addText(
    slide,
    "Application/service account is the main boundary. If a broad tool path exists, different users can receive the same overbroad result.",
    116,
    270,
    450,
    116,
    { fontSize: 22, color: C.ink }
  );
  addText(slide, "Risk: prompt asks for every salary and SSN.", 116, 420, 420, 44, {
    fontSize: 22,
    bold: true,
    color: C.oxide,
  });
  addBox(slide, "after", 674, 168, 520, 356, C.sageLight, C.sage);
  addText(slide, "After DDS", 704, 204, 300, 44, { fontSize: 32, bold: true, color: C.sage });
  addText(
    slide,
    "The same query reaches the database with end-user context. Data grants return only the rows and cells allowed for that user.",
    704,
    270,
    450,
    116,
    { fontSize: 22, color: C.ink }
  );
  addText(slide, "Control: declarative SQL policy at the data tier.", 704, 420, 420, 44, {
    fontSize: 22,
    bold: true,
    color: C.sage,
  });
  addFooter(slide, "For public demos, show the unsafe baseline only in a lab route; production should be default-deny or role-bound.");
}

{
  const slide = deck.slides.add();
  slide.background.fill = C.bg;
  addTitle(slide, "Live proof: same prompt and SQL, different result", "Alex is manager; Indira is employee.");
  addMiniTable(
    slide,
    ["User", "OCI IAM group", "Prompt", "Returned result"],
    [
      ["Alex", "DeepSec_Manager + Employee", "show me every employee salary and ssn", "4 rows: Alex + direct reports. Direct-report SSN blank."],
      ["Indira", "DeepSec_Employee", "show me every employee salary and ssn", "1 row: Indira Darshni only."],
    ],
    64,
    154,
    [150, 260, 380, 390],
    82
  );
  addBox(slide, "sql-box", 114, 410, 1050, 130, C.ink, C.ink);
  addText(
    slide,
    "SELECT employee_id, first_name, last_name, job_code, department_id, ssn, phone_number, salary, user_name, manager_id\nFROM hr.employees\nORDER BY employee_id",
    140,
    435,
    980,
    84,
    { typeface: "Aptos Mono", fontSize: 20, color: "#F7F3EC" }
  );
  addFooter(slide, "The SQL requests SSN and salary for everyone; Deep Data Security decides the allowed output.");
}

{
  const slide = deck.slides.add();
  slide.background.fill = C.bg;
  addTitle(slide, "Alex manager result", "Four rows returned; direct-report SSNs are blank.");
  slide.images.add({
    blob: await imageBlob(ALEX_SCREEN),
    contentType: "image/png",
    alt: "Alex manager result screenshot",
    fit: "contain",
    position: { left: 80, top: 145, width: 1120, height: 455 },
    geometry: "roundRect",
    borderRadius: "rounded-lg",
  });
  addFooter(slide, "Alex has manager and employee roles, so he sees his own row and direct reports.");
}

{
  const slide = deck.slides.add();
  slide.background.fill = C.bg;
  addTitle(slide, "Indira employee result", "Same overpull prompt; one row returned.");
  slide.images.add({
    blob: await imageBlob(INDIRA_SCREEN),
    contentType: "image/png",
    alt: "Indira employee result screenshot",
    fit: "contain",
    position: { left: 80, top: 145, width: 1120, height: 455 },
    geometry: "roundRect",
    borderRadius: "rounded-lg",
  });
  addFooter(slide, "Indira has only the employee role, so the database returns only her HR row.");
}

{
  const slide = deck.slides.add();
  slide.background.fill = C.bg;
  addTitle(slide, "Advanced extension: Anuj and Avinash onboarding", "A before-and-after story that makes the setup steps easy to understand.");
  addMiniTable(
    slide,
    ["Stage", "Anuj: manager", "Avinash: employee", "Message"],
    [
      ["Before", "Lab baseline can show same broad service-account result.", "Lab baseline can show same broad service-account result.", "Authentication exists, but role-aware database policy is not configured."],
      ["Configure", "Add HR row + DeepSec_Manager + DeepSec_Employee.", "Add HR row + DeepSec_Employee.", "Map OCI IAM groups to database data roles."],
      ["After", "Own row plus direct reports; sensitive cells restricted.", "Own row only.", "Same SQL becomes role-aware inside Oracle 26ai."],
    ],
    54,
    166,
    [150, 290, 290, 430],
    94
  );
  addFooter(slide, "Use this as the client-facing before/after arc: first show the risk, then show the declarative fix.");
}

{
  const slide = deck.slides.add();
  slide.background.fill = C.bg;
  addTitle(slide, "Implementation checklist", "Small setup, strong control point.");
  addMiniTable(
    slide,
    ["Layer", "What to configure"],
    [
      ["OCI IAM", "Users, groups, DB Resource app, AI Agent Client app, group access-token claim."],
      ["DBaaS 26ai", "OCI_IAM identity provider, TCPS trust, AI_AGENT_SVC, application identity."],
      ["Deep Data Security", "IAM group-mapped data roles and SQL data grants on HR.EMPLOYEES."],
      ["Python app", "Authorization Code login, client credential token, end-user security context."],
      ["Demo proof", "Same prompt and SQL for Alex/Indira; compare returned rows and SSN cells."],
    ],
    115,
    160,
    [250, 820],
    74
  );
  addBox(slide, "close", 115, 586, 820, 54, C.sageLight, C.sage);
  addText(slide, "Closing line: the agent asks broadly; the database answers safely.", 136, 600, 780, 30, {
    fontSize: 24,
    bold: true,
    color: C.ink,
  });
}

for (const [index, slide] of deck.slides.items.entries()) {
  const stem = `slide-${String(index + 1).padStart(2, "0")}`;
  await saveBlobToFile(
    await deck.export({ slide, format: "png", scale: 1 }),
    path.join(PREVIEW_DIR, `${stem}.png`)
  );
  await fs.writeFile(
    path.join(LAYOUT_DIR, `${stem}.layout.json`),
    await (await slide.export({ format: "layout" })).text(),
    "utf8"
  );
}

await saveBlobToFile(
  await deck.export({ format: "webp", montage: true, scale: 1 }),
  path.join(PREVIEW_DIR, "deck-montage.webp")
);

const pptx = await PresentationFile.exportPptx(deck);
await pptx.save(FINAL_PPTX);

await fs.writeFile(
  path.join(QA_DIR, "visual-qa.txt"),
  [
    "Visual QA",
    "",
    "Rendered final slides to PNG and a deck montage.",
    "Deck includes the verified Alex and Indira screenshots.",
    "Advanced scenario is labelled as lab-only for the before state.",
    "Remaining production note: replace public IP with HTTPS DNS before external publication.",
  ].join("\n"),
  "utf8"
);

const stat = await fs.stat(FINAL_PPTX);
console.log(JSON.stringify({ finalPptx: FINAL_PPTX, bytes: stat.size, slides: deck.slides.items.length }, null, 2));
