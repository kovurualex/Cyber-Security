import fs from "node:fs/promises";
import path from "node:path";
import {
  ensureArtifactToolWorkspace,
  importArtifactTool,
  saveBlobToFile,
} from "/Users/akovuru/.codex/plugins/cache/openai-primary-runtime/presentations/26.614.11602/skills/presentations/scripts/artifact_tool_utils.mjs";

const WORKSPACE = "/private/tmp/codex-presentations/manual-deepsec/dds-agent-demo";
const TMP_DIR = path.join(WORKSPACE, "tmp");
const PREVIEW_DIR = path.join(TMP_DIR, "preview");
const LAYOUT_DIR = path.join(TMP_DIR, "layout");
const QA_DIR = path.join(TMP_DIR, "qa");
const OUTPUT_DIR = "/Users/akovuru/Documents/Deep_Data_Security-AI-Security-Agent/outputs";
const FINAL_PPTX = path.join(OUTPUT_DIR, "deep-data-security-ai-agent-demo.pptx");

await ensureArtifactToolWorkspace(WORKSPACE);
const { Presentation, PresentationFile } = await importArtifactTool(WORKSPACE);

await fs.mkdir(PREVIEW_DIR, { recursive: true });
await fs.mkdir(LAYOUT_DIR, { recursive: true });
await fs.mkdir(QA_DIR, { recursive: true });
await fs.mkdir(OUTPUT_DIR, { recursive: true });

await fs.writeFile(
  path.join(TMP_DIR, "source-notes.txt"),
  [
    "Source notes",
    "",
    "User-provided sample screenshot: HCM example same table, different allowed result. Used for visual direction only: beige background, dark green header, simple comparison table.",
    "User-provided SQL/demo model: HR.EMPLOYEES table, HR.MANAGERS lookup, local Deep Sec end users emma and marvin, data roles HRAPP_EMPLOYEES and HRAPP_MANAGERS, data grants HRAPP_EMPLOYEE_ACCESS and HRAPP_MANAGER_ACCESS.",
    "Repo source: sql/20_setup_hr_demo.sql and README.md in /Users/akovuru/Documents/Deep_Data_Security-AI-Security-Agent.",
    "Claims in deck are conceptual demo claims, not external benchmark metrics.",
  ].join("\n"),
  "utf8",
);

await fs.writeFile(
  path.join(TMP_DIR, "slide-plan.txt"),
  [
    "Slide plan",
    "",
    "Mode: create. Two-slide editable PowerPoint deck.",
    "Audience: DB/security/application owners evaluating AI-agent integration with Oracle AI Database 26ai Deep Data Security.",
    "Palette: warm ivory #F7F3EC dominant; ink #18221C; sage #2E7D54; oxide #A33A2B; muted text #4F5A52; line #18221C.",
    "Fonts: Aptos Display for titles; Aptos for body/table text; Aptos Mono for short SQL/policy labels.",
    "Scale: slide titles 32-34px; section headers 18-22px; table body 22-25px; footers 14-18px.",
    "Slide 1: simple flow showing existing HCM app -> AI agent with LLM/RAG/MCP -> Oracle 26ai Deep Data Security -> allowed result.",
    "Slide 2: persona table mirroring screenshot: Emma and Marvin, same broad agent request, different allowed rows/cells.",
  ].join("\n"),
  "utf8",
);

const W = 1280;
const H = 720;
const C = {
  bg: "#F7F3EC",
  ink: "#18221C",
  muted: "#4F5A52",
  sage: "#2E7D54",
  sageLight: "#E6F0E8",
  oxide: "#A33A2B",
  oxideLight: "#F3E4DF",
  line: "#18221C",
  white: "#FFFDF8",
  gold: "#C9A227",
  blue: "#2F6F9F",
};

const presentation = Presentation.create({ slideSize: { width: W, height: H } });

function addText(slide, text, x, y, w, h, style = {}) {
  const shape = slide.shapes.add({
    geometry: "textbox",
    position: { left: x, top: y, width: w, height: h },
    fill: "none",
    line: { style: "solid", fill: "none", width: 0 },
  });
  shape.text = text;
  shape.text.style = {
    typeface: style.typeface || "Aptos",
    fontSize: style.fontSize || 20,
    bold: Boolean(style.bold),
    color: style.color || C.ink,
    alignment: style.alignment || "left",
  };
  return shape;
}

function addBox(slide, name, x, y, w, h, fill, line = C.line, radius = 6) {
  return slide.shapes.add({
    geometry: "rect",
    name,
    position: { left: x, top: y, width: w, height: h },
    fill,
    line: { style: "solid", fill: line, width: 1.4 },
    borderRadius: radius,
  });
}

function addBadge(slide, text, x, y, w, fill, color = C.ink) {
  const badge = slide.shapes.add({
    geometry: "roundRect",
    position: { left: x, top: y, width: w, height: 32 },
    fill,
    line: { style: "solid", fill, width: 1 },
    borderRadius: "rounded-full",
  });
  badge.text = text;
  badge.text.style = {
    typeface: "Aptos",
    fontSize: 14,
    bold: true,
    color,
    alignment: "center",
  };
  return badge;
}

function addArrow(slide, x1, y1, x2, y2, color = C.muted) {
  return slide.shapes.add({
    geometry: "line",
    position: { left: x1, top: y1, width: x2 - x1, height: y2 - y1 },
    fill: "none",
    line: { style: "solid", fill: color, width: 2.2 },
    head: { type: "triangle", width: "sm", length: "sm" },
  });
}

function addFooter(slide, text) {
  addText(slide, text, 64, 668, 1152, 28, {
    fontSize: 16,
    bold: true,
    color: C.muted,
  });
}

{
  const slide = presentation.slides.add();
  slide.background.fill = C.bg;
  addText(slide, "LLM + RAG + MCP with database-enforced security", 58, 38, 1050, 52, {
    typeface: "Aptos Display",
    fontSize: 34,
    bold: true,
  });
  addText(slide, "Existing HCM app gets AI answers. Deep Data Security keeps the boundary in SQL.", 60, 88, 1000, 32, {
    fontSize: 18,
    color: C.muted,
  });

  const y = 178;
  const boxW = 230;
  const boxH = 142;
  const gap = 48;
  const xs = [64, 64 + boxW + gap, 64 + (boxW + gap) * 2, 64 + (boxW + gap) * 3];
  const titles = ["Existing system", "AI agent", "Oracle MCP server", "26ai database"];
  const body = [
    "HCM portal or service account sends the user prompt and identity.",
    "LLM plans the task; RAG adds HR policy context; agent selects a tool call.",
    "Standard tool interface calls the approved database query function.",
    "Deep Data Security applies SQL data grants before rows/cells return.",
  ];
  const fills = [C.white, C.white, C.white, C.sageLight];
  const accents = [C.blue, C.gold, C.sage, C.sage];

  for (let i = 0; i < 4; i += 1) {
    addBox(slide, `flow-${i + 1}`, xs[i], y, boxW, boxH, fills[i]);
    addBadge(slide, `${i + 1}`, xs[i] + 16, y + 16, 34, accents[i], "white");
    addText(slide, titles[i], xs[i] + 64, y + 15, boxW - 80, 28, {
      fontSize: 19,
      bold: true,
    });
    addText(slide, body[i], xs[i] + 18, y + 58, boxW - 36, 66, {
      fontSize: 15.5,
      color: C.muted,
    });
    if (i < 3) addArrow(slide, xs[i] + boxW + 8, y + 70, xs[i + 1] - 10, y + 70);
  }

  addText(slide, "Declarative SQL policy stays close to the data", 64, 388, 500, 34, {
    fontSize: 24,
    bold: true,
  });

  const policy = addBox(slide, "policy-box", 64, 430, 600, 150, C.ink, C.ink, 6);
  policy.text = [
    "CREATE DATA GRANT hr.HRAPP_MANAGER_ACCESS",
    "AS SELECT (ALL COLUMNS EXCEPT ssn)",
    "ON hr.employees",
    "WHERE manager_id = current end user",
    "TO HRAPP_MANAGERS;",
  ].join("\n");
  policy.text.style = {
    typeface: "Aptos Mono",
    fontSize: 18,
    color: "#F7F3EC",
  };

  addBox(slide, "value-box", 704, 430, 512, 150, C.white);
  addText(slide, "Why this is easy to adopt", 728, 452, 410, 28, {
    fontSize: 22,
    bold: true,
  });
  addText(
    slide,
    "Keep the agent simple: LLM + RAG + MCP decides what to ask. Oracle 26ai decides what it is allowed to see.",
    728,
    494,
    450,
    54,
    { fontSize: 19, color: C.muted },
  );
  addFooter(slide, "Value: integrate AI with existing apps, then add a database-native guardrail that follows the end user.");
}

{
  const slide = presentation.slides.add();
  slide.background.fill = C.bg;
  addText(slide, "HCM example: same agent query, different allowed result", 58, 42, 1100, 50, {
    typeface: "Aptos Display",
    fontSize: 34,
    bold: true,
  });

  const left = 58;
  const top = 130;
  const tableW = 1164;
  const headerH = 64;
  const rowH = 116;
  const col = [0, 272, 620, 900, tableW];

  addBox(slide, "table-header", left, top, tableW, headerH, C.ink, C.ink, 0);
  const headers = ["actor", "allowed scope", "returned rows", "returned cells"];
  for (let i = 0; i < 4; i += 1) {
    addText(slide, headers[i], left + col[i] + 34, top + 18, col[i + 1] - col[i] - 40, 28, {
      fontSize: 18,
      bold: true,
      color: "#D8DDD8",
    });
  }

  const rows = [
    {
      actor: "Emma",
      scope: "own HR row",
      rows: "1 row: Emma",
      cells: "personal fields OK",
      color: C.sage,
      fill: C.sageLight,
    },
    {
      actor: "Marvin",
      scope: "direct reports",
      rows: "4 rows: Marvin + team",
      cells: "direct-report SSN masked",
      color: C.oxide,
      fill: C.oxideLight,
    },
  ];

  for (let r = 0; r < rows.length; r += 1) {
    const y = top + headerH + 18 + r * rowH;
    addBox(slide, `row-${r + 1}`, left, y, tableW, rowH, C.bg, C.line, 0);
    addText(slide, rows[r].actor, left + 34, y + 34, 200, 40, {
      fontSize: 25,
      bold: true,
    });
    addText(slide, rows[r].scope, left + col[1] + 34, y + 34, 260, 40, {
      fontSize: 24,
      color: C.muted,
    });
    addText(slide, rows[r].rows, left + col[2] + 34, y + 34, 240, 40, {
      fontSize: 22,
      color: C.muted,
      bold: true,
    });
    addBadge(slide, rows[r].cells, left + col[3] + 34, y + 34, 230, rows[r].fill, rows[r].color);
  }

  addText(slide, "Agent asks:", 72, 526, 150, 28, {
    fontSize: 20,
    bold: true,
  });
  addText(slide, "\"show all employee salary and SSN\"", 218, 526, 430, 30, {
    fontSize: 20,
    bold: true,
    color: C.oxide,
  });
  addText(
    slide,
    "The LLM can ask broadly. The database returns only what Emma or Marvin is allowed to receive.",
    72,
    580,
    1090,
    34,
    { fontSize: 22, bold: true, color: C.muted },
  );
  addFooter(slide, "Deep Data Security value: policy is declarative SQL, enforced after MCP/tool execution and before data reaches the agent.");
}

for (const [index, slide] of presentation.slides.items.entries()) {
  const stem = `slide-${String(index + 1).padStart(2, "0")}`;
  await saveBlobToFile(await presentation.export({ slide, format: "png", scale: 1 }), path.join(PREVIEW_DIR, `${stem}.png`));
  await fs.writeFile(path.join(LAYOUT_DIR, `${stem}.layout.json`), await (await slide.export({ format: "layout" })).text(), "utf8");
}

await saveBlobToFile(
  await presentation.export({ format: "webp", montage: true, scale: 1 }),
  path.join(PREVIEW_DIR, "deck-montage.webp"),
);

const pptx = await PresentationFile.exportPptx(presentation);
await pptx.save(FINAL_PPTX);

await fs.writeFile(
  path.join(QA_DIR, "visual-qa.txt"),
  [
    "Visual QA",
    "",
    "Rendered both final slides to PNG and a deck montage.",
    "Checked slide structure: editable shapes/textboxes, no full-slide bitmap dependency.",
    "Design follows user-provided screenshot direction: warm background, dark header, simple comparison table.",
    "No external logos or unverified product screenshots are included.",
    "Remaining caveat: Oracle MCP wording is kept generic as an integration/tool layer, not a product UI screenshot.",
  ].join("\n"),
  "utf8",
);

const stat = await fs.stat(FINAL_PPTX);
console.log(JSON.stringify({ finalPptx: FINAL_PPTX, bytes: stat.size, slides: presentation.slides.items.length }, null, 2));
