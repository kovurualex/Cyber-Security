from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Optional


@dataclass(frozen=True)
class Operation:
    name: str
    sql: str
    extra_data_roles: tuple[str, ...] = ()


WHOAMI_SQL = """
SELECT JSON_SERIALIZE(ORA_END_USER_CONTEXT RETURNING CLOB PRETTY)
       AS end_user_context
FROM dual
"""

PROFILE_SQL = """
SELECT employee_id,
       first_name,
       last_name,
       job_code,
       department_id,
       DECODE(
         ORA_IS_COLUMN_AUTHORIZED(ssn),
         FALSE, 'NOT_AUTHORIZED',
         TRUE, ssn
       ) AS ssn,
       phone_number,
       salary,
       user_name,
       manager_id
FROM hr.employees
WHERE UPPER(user_name) = UPPER(ORA_END_USER_CONTEXT.username)
   OR manager_id IN (
       SELECT m.manager_id
       FROM hr.managers m
       WHERE UPPER(m.mgr_user_name) = UPPER(ORA_END_USER_CONTEXT.username)
   )
ORDER BY employee_id
"""

OVERPULL_SQL = """
SELECT employee_id,
       first_name,
       last_name,
       job_code,
       department_id,
       ssn,
       phone_number,
       salary,
       user_name,
       manager_id
FROM hr.employees
ORDER BY employee_id
"""

SALARY_SUMMARY_SQL = """
SELECT department_id,
       COUNT(*) AS employee_count,
       MIN(salary) AS min_salary,
       MAX(salary) AS max_salary,
       ROUND(AVG(salary), 2) AS avg_salary
FROM hr.employees
GROUP BY department_id
ORDER BY department_id
"""


OPERATIONS = {
    "whoami": Operation("whoami", WHOAMI_SQL),
    "profile": Operation("profile", PROFILE_SQL),
    "team": Operation("team", PROFILE_SQL),
    "attempt_overpull": Operation("attempt_overpull", OVERPULL_SQL),
    "salary_summary": Operation(
        "salary_summary",
        SALARY_SUMMARY_SQL,
    ),
}


def plan_operation(question: str) -> Operation:
    """Tiny deterministic planner for the demo agent."""
    q = question.casefold()
    if any(term in q for term in ("who am i", "context", "identity")):
        return OPERATIONS["whoami"]
    if any(term in q for term in ("summary", "average", "avg", "aggregate")):
        return OPERATIONS["salary_summary"]
    if any(term in q for term in ("all", "every", "ssn", "everything", "dump")):
        return OPERATIONS["attempt_overpull"]
    if any(term in q for term in ("team", "direct report", "reports")):
        return OPERATIONS["team"]
    return OPERATIONS["profile"]


def merge_data_roles(
    operation: Operation,
    requested_roles: Optional[Iterable[str]] = None,
) -> list[str]:
    roles = list(operation.extra_data_roles)
    if requested_roles:
        roles.extend(requested_roles)
    return roles
