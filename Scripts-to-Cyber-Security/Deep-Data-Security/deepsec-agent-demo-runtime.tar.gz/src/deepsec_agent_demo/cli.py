from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union

from .agent import merge_data_roles, plan_operation
from .config import Settings
from .oauth import OciOAuthClient, TokenError
from .simulate import simulate_operation


def main(argv: Optional[list[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        prog="deepsec-agent-demo",
        description="Run the Oracle Deep Data Security AI agent demo.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    ask_parser = subparsers.add_parser("ask", help="Ask the demo agent a question")
    ask_parser.add_argument("--persona", required=True, choices=("employee", "manager"))
    ask_parser.add_argument("--question", required=True)
    ask_parser.add_argument("--end-user-token", default=None)
    ask_parser.add_argument("--end-user-token-file", default=None)
    ask_parser.add_argument("--local-end-user", default=None)
    ask_parser.add_argument("--local-end-user-key", default=None)
    ask_parser.add_argument("--local-end-user-key-file", default=None)
    ask_parser.add_argument("--db-token-file", default=None)
    ask_parser.add_argument("--extra-data-role", action="append", default=[])
    ask_parser.add_argument("--print-sql", action="store_true")

    simulate_parser = subparsers.add_parser(
        "simulate",
        help="Show expected policy behavior without connecting to a database",
    )
    simulate_parser.add_argument("--persona", required=True, choices=("employee", "manager"))
    simulate_parser.add_argument("--question", required=True)
    simulate_parser.add_argument("--print-sql", action="store_true")

    web_parser = subparsers.add_parser(
        "web",
        help="Run the MFA-friendly Auth Code + PKCE browser demo",
    )
    web_parser.add_argument("--host", default=os.getenv("WEB_HOST", "0.0.0.0"))
    web_parser.add_argument("--port", type=int, default=int(os.getenv("WEB_PORT", "8091")))

    args = parser.parse_args(argv)

    if args.command == "ask":
        settings = Settings.from_env()
        return run_ask(settings, args)
    if args.command == "simulate":
        return run_simulate(args)
    if args.command == "web":
        from .web import run_web

        settings = Settings.from_env()
        return run_web(settings, host=args.host, port=args.port)

    parser.error(f"Unknown command: {args.command}")
    return 2


def run_ask(settings: Settings, args: argparse.Namespace) -> int:
    from .db import DeepSecConnection

    operation = plan_operation(args.question)
    roles = merge_data_roles(operation, args.extra_data_role)

    try:
        db_token = read_token_file(args.db_token_file) if args.db_token_file else fetch_db_token(settings)
        end_user = resolve_end_user_identity(settings, args)
    except TokenError as exc:
        print(f"Token error: {exc}", file=sys.stderr)
        return 1

    if args.print_sql:
        print(f"Planned operation: {operation.name}", file=sys.stderr)
        if roles:
            print(f"Additional data roles requested: {', '.join(roles)}", file=sys.stderr)
        print(operation.sql.strip(), file=sys.stderr)

    with DeepSecConnection(settings) as conn:
        rows = conn.run_as_end_user(
            end_user_identity=end_user.identity,
            database_access_token=db_token,
            data_roles=roles,
            action=operation.name,
            sql=operation.sql,
            client_identifier=end_user.client_identifier,
        )

    print(json.dumps(rows, indent=2, default=str))
    return 0


def run_simulate(args: argparse.Namespace) -> int:
    operation = plan_operation(args.question)
    if args.print_sql:
        print(f"Planned operation: {operation.name}", file=sys.stderr)
        if operation.extra_data_roles:
            print(
                f"Additional data roles requested: {', '.join(operation.extra_data_roles)}",
                file=sys.stderr,
            )
        print(operation.sql.strip(), file=sys.stderr)

    rows = simulate_operation(args.persona, operation)
    print(json.dumps(rows, indent=2, default=str))
    return 0


def fetch_db_token(settings: Settings) -> str:
    oauth = OciOAuthClient(
        domain_url=settings.oci_domain_url,
        client_id=settings.oci_app_client_id,
        client_secret=settings.oci_app_client_secret,
    )
    return oauth.client_credentials_token(settings.oci_db_scope)


@dataclass(frozen=True)
class ResolvedEndUser:
    identity: Union[str, tuple[str, str]]
    client_identifier: str


def resolve_end_user_identity(settings: Settings, args: argparse.Namespace) -> ResolvedEndUser:
    if args.local_end_user:
        key = args.local_end_user_key
        if args.local_end_user_key_file:
            key = read_token_file(args.local_end_user_key_file)
        if not key:
            raise TokenError("--local-end-user requires --local-end-user-key or --local-end-user-key-file.")
        return ResolvedEndUser((args.local_end_user, key), args.local_end_user)

    if args.end_user_token:
        return ResolvedEndUser(args.end_user_token.strip(), args.persona)
    if args.end_user_token_file:
        return ResolvedEndUser(read_token_file(args.end_user_token_file), args.persona)

    prefix = f"PERSONA_{args.persona.upper()}"
    local_user = os.getenv(f"{prefix}_END_USER")
    local_key = os.getenv(f"{prefix}_KEY")
    local_key_file = os.getenv(f"{prefix}_KEY_FILE")
    if local_user:
        if local_key_file:
            local_key = read_token_file(local_key_file)
        if not local_key:
            raise TokenError(f"Set {prefix}_KEY or {prefix}_KEY_FILE for local end user {local_user}.")
        return ResolvedEndUser((local_user, local_key), local_user)

    token_file = os.getenv(f"{prefix}_TOKEN_FILE")
    if token_file:
        return ResolvedEndUser(read_token_file(token_file), args.persona)

    username = os.getenv(f"{prefix}_USERNAME")
    password = os.getenv(f"{prefix}_PASSWORD")
    if not username or not password:
        raise TokenError(
            f"Set {prefix}_END_USER with {prefix}_KEY for local end users, "
            f"set {prefix}_TOKEN_FILE, pass --end-user-token-file, or set "
            f"{prefix}_USERNAME and {prefix}_PASSWORD for non-production IAM ROPC."
        )

    oauth = OciOAuthClient(
        domain_url=settings.oci_domain_url,
        client_id=settings.oci_app_client_id,
        client_secret=settings.oci_app_client_secret,
    )
    return ResolvedEndUser(
        oauth.password_token(
            username=username,
            password=password,
            scope=settings.oci_app_scope,
        ),
        username,
    )


def read_token_file(path: Optional[str]) -> str:
    if not path:
        raise TokenError("Token file path is empty.")
    token = Path(path).expanduser().read_text(encoding="utf-8").strip()
    if not token:
        raise TokenError(f"Token file is empty: {path}")
    return token
