from __future__ import annotations

from typing import Any, Optional, Union

import oracledb

from .config import Settings


class DeepSecConnection:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.connection: Optional[oracledb.Connection] = None

    def __enter__(self) -> "DeepSecConnection":
        if self.settings.oracle_thick_mode and oracledb.is_thin_mode():
            init_args: dict[str, Any] = {}
            if self.settings.oracle_client_lib_dir:
                init_args["lib_dir"] = self.settings.oracle_client_lib_dir
            if self.settings.oracle_client_config_dir:
                init_args["config_dir"] = self.settings.oracle_client_config_dir
            oracledb.init_oracle_client(**init_args)

        connect_args: dict[str, Any] = {
            "user": self.settings.oracle_user,
            "password": self.settings.oracle_password,
            "dsn": self.settings.oracle_dsn,
        }
        if self.settings.oracle_wallet_location:
            connect_args["wallet_location"] = self.settings.oracle_wallet_location
        if self.settings.oracle_wallet_password:
            connect_args["wallet_password"] = self.settings.oracle_wallet_password

        self.connection = oracledb.connect(**connect_args)
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        if self.connection is not None:
            self.connection.close()

    def run_as_end_user(
        self,
        *,
        end_user_identity: Union[str, tuple[str, str]],
        database_access_token: str,
        data_roles: list[str],
        action: str,
        sql: str,
        client_identifier: str,
    ) -> list[dict[str, Any]]:
        if self.connection is None:
            raise RuntimeError("Connection is not open.")

        user_context = oracledb.create_end_user_security_context(
            end_user_identity=end_user_identity,
            database_access_token=database_access_token,
            data_roles=data_roles or None,
        )

        self.connection.set_end_user_security_context(user_context)
        try:
            self._mark_session(client_identifier=client_identifier, action=action)
            return self._fetch(sql)
        finally:
            self.connection.clear_end_user_security_context()

    def run_as_service_account(
        self,
        *,
        action: str,
        sql: str,
        client_identifier: str,
    ) -> list[dict[str, Any]]:
        if self.connection is None:
            raise RuntimeError("Connection is not open.")

        self._mark_session(client_identifier=client_identifier, action=action)
        return self._fetch(sql)

    def _mark_session(self, *, client_identifier: str, action: str) -> None:
        assert self.connection is not None
        with self.connection.cursor() as cursor:
            cursor.callproc(
                "DBMS_APPLICATION_INFO.SET_MODULE",
                ["DeepSecAIAgentDemo", action],
            )
            cursor.callproc("DBMS_SESSION.SET_IDENTIFIER", [client_identifier])

    def _fetch(self, sql: str) -> list[dict[str, Any]]:
        assert self.connection is not None
        with self.connection.cursor() as cursor:
            cursor.execute(sql)
            columns = [col[0].lower() for col in cursor.description]
            return [
                dict(zip(columns, [normalize_value(value) for value in row]))
                for row in cursor.fetchall()
            ]


def normalize_value(value: Any) -> Any:
    if value is None:
        return None
    read = getattr(value, "read", None)
    if callable(read):
        return read()
    if isinstance(value, bytes):
        return value.hex()
    return value
