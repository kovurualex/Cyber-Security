from __future__ import annotations

import html
import json
import os
import secrets
import traceback
from typing import Any

from flask import Flask, redirect, render_template_string, request, session, url_for

from .agent import plan_operation
from .cli import fetch_db_token
from .config import Settings
from .db import DeepSecConnection
from .oauth import OciOAuthClient, TokenError, decode_jwt_claims, new_pkce_pair


PAGE = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Deep Data Security AI Agent</title>
  <style>
    body { margin: 0; font-family: Arial, sans-serif; background: #f7f7f4; color: #1f2924; }
    header { background: #1c2a23; color: white; padding: 18px 28px; }
    main { max-width: 1120px; margin: 0 auto; padding: 28px; }
    .bar { display: flex; justify-content: space-between; gap: 16px; align-items: center; flex-wrap: wrap; }
    .panel { border: 1px solid #ccd4ce; background: white; border-radius: 8px; padding: 20px; margin-top: 18px; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
    textarea { width: 100%; min-height: 90px; font: inherit; padding: 10px; box-sizing: border-box; }
    button, .button { background: #1c2a23; color: white; border: 0; border-radius: 6px; padding: 10px 14px; text-decoration: none; display: inline-block; cursor: pointer; }
    .actions { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
    .muted { color: #5d6862; }
    .tag { color: #5d6862; font-size: 14px; font-weight: 400; }
    pre { white-space: pre-wrap; background: #111814; color: #d9f7e8; padding: 14px; border-radius: 6px; overflow: auto; }
    table { border-collapse: collapse; width: 100%; background: white; }
    th, td { border-bottom: 1px solid #e0e5e1; padding: 9px; text-align: left; vertical-align: top; }
    th { background: #eef2ef; }
    .danger { color: #9c2f24; font-weight: 700; }
    .ok { color: #257344; font-weight: 700; }
    @media (max-width: 800px) { .grid { grid-template-columns: 1fr; } }
  </style>
</head>
<body>
  <header>
    <div class="bar">
      <div>
        <h1 style="margin:0;font-size:24px;">Deep Data Security AI Agent</h1>
        <div class="muted" style="color:#b7c3bd;">MFA login, same table, different allowed result</div>
      </div>
      {% if logged_in %}
        <a class="button" href="{{ url_for('logout') }}">Logout</a>
      {% else %}
        <a class="button" href="{{ url_for('login') }}">Login with OCI IAM</a>
      {% endif %}
    </div>
  </header>
  <main>
    {% if error %}
      <div class="panel danger">{{ error }}</div>
    {% endif %}
    {% if logged_in %}
      <div class="grid">
        <section class="panel">
          <h2>Signed In User</h2>
          <table>
            {% for key, value in claim_rows %}
              <tr><th>{{ key }}</th><td>{{ value }}</td></tr>
            {% endfor %}
          </table>
        </section>
        <section class="panel">
          <h2>Ask The Agent</h2>
          <form method="post" action="{{ url_for('ask') }}">
            <textarea id="question" name="question">{{ question }}</textarea>
            <p class="actions">
              <button type="submit">Run Query</button>
              <button
                type="button"
                onclick="document.getElementById('question').value = 'show me every employee salary and ssn'; document.getElementById('question').focus();"
              >Try Overpull</button>
            </p>
          </form>
        </section>
      </div>
      {% if sql %}
        <section class="panel">
          <h2>Planned SQL{% if operation_name %} <span class="tag">{{ operation_name }}</span>{% endif %}</h2>
          <pre>{{ sql }}</pre>
        </section>
      {% endif %}
      {% if rows is not none %}
        <section class="panel">
          <h2>Returned Rows</h2>
          {% if rows %}
            <table>
              <tr>
                {% for column in columns %}
                  <th>{{ column }}</th>
                {% endfor %}
              </tr>
              {% for row in rows %}
                <tr>
                  {% for column in columns %}
                    <td>{{ row[column] }}</td>
                  {% endfor %}
                </tr>
              {% endfor %}
            </table>
          {% else %}
            <p class="muted">No rows returned.</p>
          {% endif %}
        </section>
      {% endif %}
    {% else %}
      <section class="panel">
        <h2>Demo Flow</h2>
        <p>Login redirects to OCI IAM, including MFA. The Python app receives a user access token, gets its own database access token, and sends both to Oracle AI Database 26ai.</p>
        <p>The database applies Deep Data Security data grants. The agent can ask for too much, but the returned rows and columns stay inside the signed-in user's boundary.</p>
      </section>
    {% endif %}
  </main>
</body>
</html>
"""


def run_web(settings: Settings, *, host: str, port: int) -> int:
    app = create_app(settings)
    app.run(host=host, port=port)
    return 0


def create_app(settings: Settings) -> Flask:
    app = Flask(__name__)
    app.secret_key = os.getenv("FLASK_SECRET_KEY", secrets.token_hex(32))
    oauth = OciOAuthClient(
        domain_url=settings.oci_domain_url,
        client_id=settings.oci_app_client_id,
        client_secret=settings.oci_app_client_secret,
    )

    @app.get("/")
    def index() -> str:
        return render_page()

    @app.get("/login")
    def login():
        verifier, challenge = new_pkce_pair()
        state = secrets.token_urlsafe(32)
        session["pkce_verifier"] = verifier
        session["oauth_state"] = state
        return redirect(
            oauth.authorization_url(
                redirect_uri=redirect_uri(),
                scope=settings.oci_app_scope or settings.oci_db_scope,
                state=state,
                code_challenge=challenge,
            )
        )

    @app.get("/callback")
    def callback():
        error = request.args.get("error")
        if error:
            return render_page(error=f"OCI IAM returned error: {error}")
        if request.args.get("state") != session.get("oauth_state"):
            return render_page(error="State mismatch. Start login again.")
        code = request.args.get("code")
        verifier = session.get("pkce_verifier")
        if not code or not verifier:
            return render_page(error="Missing authorization code or PKCE verifier.")
        try:
            token = oauth.authorization_code_token(
                code=code,
                redirect_uri=redirect_uri(),
                code_verifier=verifier,
            )
        except TokenError as exc:
            return render_page(error=str(exc))
        session["user_token"] = token
        session["claims"] = decode_jwt_claims(token)
        return redirect(url_for("index"))

    @app.post("/ask")
    def ask() -> str:
        token = session.get("user_token")
        if not token:
            return redirect(url_for("login"))
        question = request.form.get("question", "who am i").strip() or "who am i"
        operation = plan_operation(question)
        try:
            with DeepSecConnection(settings) as conn:
                if settings.demo_security_mode == "baseline":
                    rows = conn.run_as_service_account(
                        action=f"baseline_{operation.name}",
                        sql=operation.sql,
                        client_identifier=client_identifier(session.get("claims", {})),
                    )
                else:
                    db_token = fetch_db_token(settings)
                    rows = conn.run_as_end_user(
                        end_user_identity=token,
                        database_access_token=db_token,
                        data_roles=[],
                        action=operation.name,
                        sql=operation.sql,
                        client_identifier=client_identifier(session.get("claims", {})),
                    )
        except Exception as exc:  # Keep the lab page useful; server logs retain details.
            traceback.print_exc()
            if "ORA-52601" in str(exc):
                session.pop("user_token", None)
                session.pop("claims", None)
                return render_page(
                    error=(
                        "Your OCI IAM access token expired. Click Login with OCI IAM "
                        "again, complete MFA, and rerun the query."
                    ),
                    question=question,
                    sql=operation.sql.strip(),
                    operation_name=operation.name,
                )
            return render_page(
                error=str(exc),
                question=question,
                sql=operation.sql.strip(),
                operation_name=operation.name,
            )
        return render_page(
            question=question,
            sql=operation.sql.strip(),
            rows=display_rows(rows),
            operation_name=operation.name,
        )

    @app.get("/logout")
    def logout():
        session.clear()
        return redirect(url_for("index"))

    def render_page(
        *,
        error: str | None = None,
        question: str = "who am i",
        sql: str | None = None,
        operation_name: str | None = None,
        rows: list[dict[str, Any]] | None = None,
    ) -> str:
        claims = session.get("claims") or {}
        claim_rows = [
            ("username", format_cell(client_identifier(claims))),
            ("sub", format_cell(claims.get("sub", ""))),
            ("client_id", format_cell(claims.get("client_id", ""))),
            ("scope", format_cell(claims.get("scope", ""))),
            ("group", format_cell(claims.get("group", claims.get("groups", "")))),
            ("grant type", format_cell(claims.get("gtp", claims.get("grant_type", "")))),
        ]
        return render_template_string(
            PAGE,
            logged_in=bool(session.get("user_token")),
            claim_rows=claim_rows,
            error=error,
            question=question,
            sql=sql,
            operation_name=operation_name,
            rows=rows,
            columns=list(rows[0].keys()) if rows else [],
        )

    def redirect_uri() -> str:
        return os.getenv("WEB_REDIRECT_URI", f"{public_base_url()}/callback")

    return app


def public_base_url() -> str:
    return os.getenv("WEB_BASE_URL", "http://localhost:8091").rstrip("/")


def client_identifier(claims: dict[str, Any]) -> str:
    for key in ("preferred_username", "user_name", "username", "sub"):
        value = claims.get(key)
        if isinstance(value, str) and value:
            return value
    return "oci-user"


def display_rows(rows: list[dict[str, Any]]) -> list[dict[str, str]]:
    return [
        {key: format_cell(value) for key, value in row.items()}
        for row in rows
    ]


def format_cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, indent=2, default=str)
    text = str(value)
    if len(text) > 4000:
        return text[:4000] + "\n...truncated..."
    return text
