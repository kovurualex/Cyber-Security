from __future__ import annotations

import base64
import json
import secrets
import hashlib
from dataclasses import dataclass
from typing import Any
from urllib import parse, request
from urllib.error import HTTPError, URLError


class TokenError(RuntimeError):
    pass


@dataclass(frozen=True)
class OciOAuthClient:
    domain_url: str
    client_id: str
    client_secret: str

    def client_credentials_token(self, scope: str) -> str:
        return self._token(
            {
                "grant_type": "client_credentials",
                "scope": scope,
            }
        )

    def password_token(self, *, username: str, password: str, scope: str) -> str:
        return self._token(
            {
                "grant_type": "password",
                "username": username,
                "password": password,
                "scope": scope,
            }
        )

    def authorization_url(
        self,
        *,
        redirect_uri: str,
        scope: str,
        state: str,
        code_challenge: str,
    ) -> str:
        query = parse.urlencode(
            {
                "response_type": "code",
                "client_id": self.client_id,
                "redirect_uri": redirect_uri,
                "scope": scope,
                "state": state,
                "code_challenge": code_challenge,
                "code_challenge_method": "S256",
            }
        )
        return f"{self.domain_url.rstrip('/')}/oauth2/v1/authorize?{query}"

    def authorization_code_token(
        self,
        *,
        code: str,
        redirect_uri: str,
        code_verifier: str,
    ) -> str:
        return self._token(
            {
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": redirect_uri,
                "code_verifier": code_verifier,
            }
        )

    def _token(self, form: dict[str, str]) -> str:
        endpoint = f"{self.domain_url.rstrip('/')}/oauth2/v1/token"
        body = parse.urlencode(form).encode("utf-8")
        req = request.Request(
            endpoint,
            data=body,
            headers={
                "Authorization": f"Basic {self._basic_auth()}",
                "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
            },
            method="POST",
        )

        try:
            with request.urlopen(req, timeout=30) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise TokenError(f"OCI IAM token request failed: HTTP {exc.code} {detail}") from exc
        except URLError as exc:
            raise TokenError(f"OCI IAM token request failed: {exc.reason}") from exc
        except json.JSONDecodeError as exc:
            raise TokenError("OCI IAM token response was not JSON.") from exc

        return extract_access_token(payload)

    def _basic_auth(self) -> str:
        raw = f"{self.client_id}:{self.client_secret}".encode("utf-8")
        return base64.b64encode(raw).decode("ascii")


def extract_access_token(payload: dict[str, Any]) -> str:
    token = payload.get("access_token")
    if not isinstance(token, str) or not token:
        raise TokenError(f"Token response did not contain access_token: {payload}")
    return token


def decode_jwt_claims(token: str) -> dict[str, Any]:
    parts = token.split(".")
    if len(parts) < 2:
        return {}
    payload = parts[1] + "=" * (-len(parts[1]) % 4)
    try:
        return json.loads(base64.urlsafe_b64decode(payload.encode()).decode())
    except (ValueError, json.JSONDecodeError):
        return {}


def new_pkce_pair() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(64)
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).decode("ascii").rstrip("=")
    return verifier, challenge
