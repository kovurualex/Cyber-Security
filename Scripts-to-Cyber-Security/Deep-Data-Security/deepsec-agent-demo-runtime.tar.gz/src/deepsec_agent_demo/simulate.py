from __future__ import annotations

from typing import Any, Optional

from .agent import Operation


EMPLOYEES = [
    {
        "employee_id": 1,
        "first_name": "Grace",
        "last_name": "Young",
        "job_code": "CEO",
        "department_id": None,
        "ssn": "111-11-1111",
        "phone_number": "555-100-0001",
        "salary": 235000,
        "user_name": "grace",
        "manager_id": None,
    },
    {
        "employee_id": 2,
        "first_name": "Marvin",
        "last_name": "Morgan",
        "job_code": "SWE_MGR",
        "department_id": 1,
        "ssn": "222-22-2222",
        "phone_number": "555-100-0002",
        "salary": 175000,
        "user_name": "marvin",
        "manager_id": 1,
    },
    {
        "employee_id": 3,
        "first_name": "Emma",
        "last_name": "Baker",
        "job_code": "SWE2",
        "department_id": 1,
        "ssn": "333-33-3333",
        "phone_number": "555-100-0003",
        "salary": 120000,
        "user_name": "emma",
        "manager_id": 2,
    },
    {
        "employee_id": 4,
        "first_name": "Charlie",
        "last_name": "Davis",
        "job_code": "SWE1",
        "department_id": 1,
        "ssn": "444-44-4444",
        "phone_number": "555-100-0004",
        "salary": 95000,
        "user_name": "charlie",
        "manager_id": 2,
    },
    {
        "employee_id": 5,
        "first_name": "Dana",
        "last_name": "Lee",
        "job_code": "SWE3",
        "department_id": 1,
        "ssn": "555-55-5555",
        "phone_number": "555-100-0005",
        "salary": 130000,
        "user_name": "dana",
        "manager_id": 2,
    },
    {
        "employee_id": 6,
        "first_name": "Bob",
        "last_name": "Smith",
        "job_code": "SALES_REP",
        "department_id": 2,
        "ssn": "666-66-6666",
        "phone_number": "555-100-0006",
        "salary": 145000,
        "user_name": "bob",
        "manager_id": 1,
    },
    {
        "employee_id": 7,
        "first_name": "Fiona",
        "last_name": "Chen",
        "job_code": "HR_REP",
        "department_id": 3,
        "ssn": "777-77-7777",
        "phone_number": "555-100-0007",
        "salary": 92000,
        "user_name": "fiona",
        "manager_id": 1,
    },
]

PERSONAS = {
    "employee": {
        "username": "emma",
        "roles": ("HRAPP_EMPLOYEES",),
    },
    "manager": {
        "username": "marvin",
        "roles": ("HRAPP_EMPLOYEES", "HRAPP_MANAGERS"),
    },
}


def simulate_operation(persona: str, operation: Operation) -> list[dict[str, Any]]:
    identity = PERSONAS[persona]
    username = str(identity["username"])
    roles = set(identity["roles"])

    if operation.name == "whoami":
        return [{"username": username, "data_roles": sorted(roles)}]

    rows = visible_employee_rows(username=username, roles=roles)
    if operation.name == "salary_summary":
        return salary_summary(rows)
    return rows


def visible_employee_rows(*, username: str, roles: set[str]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    manager_employee_id = employee_id_for(username)

    for row in EMPLOYEES:
        own_row = "HRAPP_EMPLOYEES" in roles and row["user_name"].upper() == username.upper()
        direct_report = (
            "HRAPP_MANAGERS" in roles
            and manager_employee_id is not None
            and row["manager_id"] == manager_employee_id
        )
        if not own_row and not direct_report:
            continue

        visible = dict(row)
        if direct_report and not own_row:
            visible["ssn"] = "NOT_AUTHORIZED"
        rows.append(visible)

    return rows


def employee_id_for(username: str) -> Optional[int]:
    for row in EMPLOYEES:
        if row["user_name"].upper() == username.upper():
            return int(row["employee_id"])
    return None


def salary_summary(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_department: dict[str, list[int]] = {}
    for row in rows:
        department = "NULL" if row["department_id"] is None else str(row["department_id"])
        by_department.setdefault(department, []).append(int(row["salary"]))

    results = []
    for department_id, salaries in sorted(by_department.items()):
        results.append(
            {
                "department_id": department_id,
                "employee_count": len(salaries),
                "min_salary": min(salaries),
                "max_salary": max(salaries),
                "avg_salary": round(sum(salaries) / len(salaries), 2),
            }
        )
    return results
