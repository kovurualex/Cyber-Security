from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Settings:
    oracle_dsn: str
    oracle_user: str
    oracle_password: str
    oracle_thick_mode: bool
    oci_domain_url: str
    oci_app_client_id: str
    oci_app_client_secret: str
    oci_db_scope: str
    oci_app_scope: str
    oracle_wallet_location: Optional[str] = None
    oracle_wallet_password: Optional[str] = None
    oracle_client_lib_dir: Optional[str] = None
    oracle_client_config_dir: Optional[str] = None
    demo_security_mode: str = "dds"

    @classmethod
    def from_env(cls) -> "Settings":
        load_dotenv_if_present()
        return cls(
            oracle_dsn=require_env("ORACLE_DSN"),
            oracle_user=os.getenv("ORACLE_USER", "AI_AGENT_SVC"),
            oracle_password=require_env("ORACLE_PASSWORD"),
            oracle_thick_mode=truthy(os.getenv("ORACLE_THICK_MODE")),
            oracle_client_lib_dir=os.getenv("ORACLE_CLIENT_LIB_DIR"),
            oracle_client_config_dir=os.getenv("ORACLE_CLIENT_CONFIG_DIR"),
            demo_security_mode=os.getenv("DEMO_SECURITY_MODE", "dds").strip().casefold(),
            oracle_wallet_location=os.getenv("ORACLE_WALLET_LOCATION"),
            oracle_wallet_password=os.getenv("ORACLE_WALLET_PASSWORD"),
            oci_domain_url=require_env("OCI_DOMAIN_URL").rstrip("/"),
            oci_app_client_id=require_env("OCI_APP_CLIENT_ID"),
            oci_app_client_secret=require_env("OCI_APP_CLIENT_SECRET"),
            oci_db_scope=require_env("OCI_DB_SCOPE"),
            oci_app_scope=os.getenv("OCI_APP_SCOPE", ""),
        )


def require_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise RuntimeError(f"Missing required environment variable: {name}")
    return value


def truthy(value: Optional[str]) -> bool:
    return value is not None and value.casefold() in {"1", "true", "yes", "on"}


def load_dotenv_if_present(path: str = ".env") -> None:
    if not os.path.exists(path):
        return

    with open(path, encoding="utf-8") as handle:
        for line in handle:
            stripped = line.strip()
            if not stripped or stripped.startswith("#") or "=" not in stripped:
                continue
            key, value = stripped.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            os.environ.setdefault(key, value)
